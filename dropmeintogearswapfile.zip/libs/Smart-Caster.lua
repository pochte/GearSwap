-------------------------------------------------------------------------------------------------------------------
-- SMART CASTER
-- SCH Stratagems, Storm Prep, WHM Afflatus, Klimaform, Sublimation Auto
-- Author: Lady Ullona | Retail FFXI / Windower
--
-- USAGE:
--   Place in your GearSwap/data/ folder.
--   In your job file's get_sets(), add:
--       include('Smart-Caster.lua')
--
--   Then wire up the helpers in your job file's own hook functions:
--
--       function job_precast(spell, spellMap, eventArgs)
--           smart_caster_precast(spell, spellMap, eventArgs)
--           -- ... rest of your precast logic ...
--       end
--
--       function job_aftercast(spell, spellMap, eventArgs)
--           try_sublimation()
--           -- ... rest of your aftercast logic ...
--       end
--
--       function job_buff_change(buff, gain)
--           smart_caster_buff_change(buff, gain)
--           -- ... rest of your buff_change logic ...
--       end
--
-- NOTE: Do NOT define job_precast / job_aftercast / job_buff_change inside
--       this file — doing so would silently overwrite your job file's versions.
--       Call the helper functions from your job file instead (as shown above).
-------------------------------------------------------------------------------------------------------------------

local LATENCY             = 0.1   -- seconds; recast must be below this to fire
local SUBLIMATION_INTERVAL = 5    -- seconds between sublimation re-checks
local sublimation_last_check = 0

-------------------------------------------------------------------------------------------------------------------
-- STRING HELPERS
-------------------------------------------------------------------------------------------------------------------
-- Safe startswith that won't error on nil strings
function string.startswith(str, prefix)
    return str and str:sub(1, #prefix) == prefix
end

-------------------------------------------------------------------------------------------------------------------
-- SCH HELPERS
-------------------------------------------------------------------------------------------------------------------
-- Returns 'light', 'dark', or 'none' depending on active Arts buff
function get_current_arts()
    if buffactive['Light Arts'] or buffactive['Addendum: White'] then
        return 'light'
    elseif buffactive['Dark Arts'] or buffactive['Addendum: Black'] then
        return 'dark'
    end
    return 'none'
end

-------------------------------------------------------------------------------------------------------------------
-- WEATHER CHECK
-- Returns true if the given element's weather or self-cast storm is active
-------------------------------------------------------------------------------------------------------------------
function has_weather(element)
    if world.weather_element == element then return true end

    local storms = {
        Fire      = 'Firestorm',
        Ice       = 'Hailstorm',
        Wind      = 'Windstorm',
        Earth     = 'Sandstorm',
        Lightning = 'Thunderstorm',
        Water     = 'Rainstorm',
        Light     = 'Aurorastorm',
        Dark      = 'Voidstorm',
    }

    return storms[element] and buffactive[storms[element]] or false
end

-------------------------------------------------------------------------------------------------------------------
-- SPELL AVAILABLE CHECK
-- Looks up a spell by name in res.spells and checks its recast timer
-------------------------------------------------------------------------------------------------------------------
function spell_available(name)
    local spell = res.spells:with('en', name)
    if not spell then return false end

    local recasts = windower.ffxi.get_spell_recasts()
    if not recasts then return false end

    return recasts[spell.recast_id] ~= nil and recasts[spell.recast_id] < LATENCY
end

-------------------------------------------------------------------------------------------------------------------
-- BLACK ENFEEBLING SPELLS (used to gate Manifestation)
-------------------------------------------------------------------------------------------------------------------
local black_enfeebles = {
    Poison=true, ['Poison II']=true, Poisonga=true, ['Poisonga II']=true,
    Bio=true, ['Bio II']=true, ['Bio III']=true,
    Blind=true, ['Blind II']=true,
    Burn=true, Choke=true, Shock=true, Drown=true, Rasp=true, Frost=true,
    Distract=true, ['Distract II']=true, ['Distract III']=true,
    Frazzle=true, ['Frazzle II']=true, ['Frazzle III']=true,
    Bind=true, Break=true, Breakga=true,
    Sleep=true, ['Sleep II']=true, Sleepga=true, ['Sleepga II']=true,
}

-------------------------------------------------------------------------------------------------------------------
-- CROWD CONTROL SPELLS
-- These must cast immediately — never prep weather first
-------------------------------------------------------------------------------------------------------------------
local crowd_control_spells = {
    Sleep=true, ['Sleep II']=true, Sleepga=true, ['Sleepga II']=true,
    Repose=true, Break=true, Breakga=true,
    Bind=true, Gravity=true, ['Gravity II']=true,
}

-------------------------------------------------------------------------------------------------------------------
-- SMART CASTER PRECAST
-- Call this at the top of your job file's job_precast().
-- Handles automatic ability usage before magic spells:
--   SCH: Auto-Arts, Aurorastorm, Celerity, Accession, Manifestation, Klimaform, Elemental Storms
--   WHM: Afflatus Solace / Misery
--   RDM: Composure
-------------------------------------------------------------------------------------------------------------------
function smart_caster_precast(spell, spellMap, eventArgs)
    if not spell or spell.action_type ~= 'Magic' then return end

    local abil_recasts = windower.ffxi.get_ability_recasts() or {}
    local arts         = get_current_arts()
    local is_sch_main  = player.main_job == 'SCH'
    local is_sch_sub   = player.sub_job  == 'SCH'
    local is_whm_main  = player.main_job == 'WHM'
    local is_rdm_main  = player.main_job == 'RDM'
    local target       = spell.target.raw or '<t>'

    -- Skip if a fast-cast stratagem is already running
    if buffactive['Alacrity'] or buffactive['Celerity'] then return end

    -------------------------------------------------------------------------------------------------------------------
    -- SCH: AUTO-ARTS
    -- Activates Light/Dark Arts if the wrong (or no) arts are up.
    -- FIX: Corrected ability recast IDs.
    --   Light Arts main=228, sub=230  |  Dark Arts main=229, sub=231
    -------------------------------------------------------------------------------------------------------------------
    if is_sch_main or is_sch_sub then
        local light_id = is_sch_main and 228 or 230  -- FIX: was 257
        local dark_id  = is_sch_main and 229 or 231  -- FIX: was 258

        if spell.skill == 'Black Magic' and arts ~= 'dark'
            and abil_recasts[dark_id] and abil_recasts[dark_id] < LATENCY then
            cancel_spell()
            send_command('input /ja "Dark Arts" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
            eventArgs.cancel = true
            return

        elseif spell.skill == 'White Magic' and arts ~= 'light'
            and abil_recasts[light_id] and abil_recasts[light_id] < LATENCY then
            cancel_spell()
            send_command('input /ja "Light Arts" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
            eventArgs.cancel = true
            return
        end
    end

    -------------------------------------------------------------------------------------------------------------------
    -- WHM: AFFLATUS SOLACE (single-target Cure spells)
    -- Ability recast ID 29 — unchanged, was already correct
    -------------------------------------------------------------------------------------------------------------------
    if is_whm_main
        and spell.skill == 'Healing Magic'
        and spell.english:startswith('Cure')
        and not spell.english:match('Curaga')
        and not buffactive['Afflatus Solace']
        and abil_recasts[29] and abil_recasts[29] < LATENCY then

        cancel_spell()
        send_command('input /ja "Afflatus Solace" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
        eventArgs.cancel = true
        return
    end

    -------------------------------------------------------------------------------------------------------------------
    -- WHM: AFFLATUS MISERY (Divine Magic and Esuna)
    -- Ability recast ID 30 — unchanged, was already correct
    -------------------------------------------------------------------------------------------------------------------
    if is_whm_main
        and (spell.skill == 'Divine Magic' or spell.english == 'Esuna')
        and not buffactive['Afflatus Misery']
        and abil_recasts[30] and abil_recasts[30] < LATENCY then

        cancel_spell()
        send_command('input /ja "Afflatus Misery" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
        eventArgs.cancel = true
        return
    end

    -------------------------------------------------------------------------------------------------------------------
    -- RDM: COMPOSURE (Enhancing Magic — keep it up)
    -- Ability recast ID 50 — unchanged, was already correct
    -------------------------------------------------------------------------------------------------------------------
    if is_rdm_main
        and spell.skill == 'Enhancing Magic'
        and not buffactive['Composure']
        and abil_recasts[50] and abil_recasts[50] < LATENCY then

        cancel_spell()
        send_command('input /ja "Composure" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
        eventArgs.cancel = true
        return
    end

    -------------------------------------------------------------------------------------------------------------------
    -- SCH: AURORASTORM (Healing Magic in Light Arts — prep Light weather first)
    -------------------------------------------------------------------------------------------------------------------
    if (is_sch_main or is_sch_sub)
        and spell.skill == 'Healing Magic'
        and arts == 'light'
        and not has_weather('Light') then

        local storm = nil
        if is_sch_main then
            storm = (spell_available('Aurorastorm II') and 'Aurorastorm II')
                 or (spell_available('Aurorastorm')    and 'Aurorastorm')
        else
            storm = spell_available('Aurorastorm') and 'Aurorastorm'
        end

        if storm then
            cancel_spell()
            send_command('input /ma "'..storm..'" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
            eventArgs.cancel = true
            return
        end
    end

    -------------------------------------------------------------------------------------------------------------------
    -- SCH: ACCESSION (status removal spells in Light Arts — make them AoE)
    -- FIX: Corrected ability recast ID 216 (was 245)
    -------------------------------------------------------------------------------------------------------------------
    if (is_sch_main or is_sch_sub)
        and spell.skill == 'Healing Magic'
        and arts == 'light'
        and not buffactive['Accession']
        and abil_recasts[216] and abil_recasts[216] < LATENCY then  -- FIX: was 245

        local accession_spells = {
            Poisona=true, Paralyna=true, Blindna=true,
            Silena=true,  Cursna=true,  Viruna=true,
            Stona=true,   Erase=true,
        }

        if accession_spells[spell.english] then
            cancel_spell()
            send_command('input /ja "Accession" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
            eventArgs.cancel = true
            return
        end
    end

    -------------------------------------------------------------------------------------------------------------------
    -- SCH: CELERITY (Cure spells in Light Arts — fast cast)
    -- FIX: Corrected ability recast ID 214 (was 244)
    -------------------------------------------------------------------------------------------------------------------
    if (is_sch_main or is_sch_sub)
        and spell.skill == 'Healing Magic'
        and spell.english:startswith('Cure')
        and arts == 'light'
        and abil_recasts[214] and abil_recasts[214] < LATENCY then  -- FIX: was 244

        cancel_spell()
        send_command('input /ja "Celerity" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
        eventArgs.cancel = true
        return
    end

    -------------------------------------------------------------------------------------------------------------------
    -- SCH: MANIFESTATION (black enfeebling in Dark Arts — make them AoE)
    -- FIX: Corrected ability recast ID 217 (was 246)
    -------------------------------------------------------------------------------------------------------------------
    if (is_sch_main or is_sch_sub)
        and spell.skill == 'Enfeebling Magic'
        and arts == 'dark'
        and black_enfeebles[spell.english]
        and not buffactive['Manifestation']
        and abil_recasts[217] and abil_recasts[217] < LATENCY then  -- FIX: was 246

        cancel_spell()
        send_command('input /ja "Manifestation" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
        eventArgs.cancel = true
        return
    end

    -------------------------------------------------------------------------------------------------------------------
    -- SCH: KLIMAFORM (Elemental Magic in Dark Arts when weather already matches)
    -- FIX: Klimaform is a Job Ability (/ja), not a spell (/ma).
    --      Was incorrectly using spell_available() and /ma.
    --      Fixed to use abil_recasts[222] and /ja.
    -------------------------------------------------------------------------------------------------------------------
    if spell.skill == 'Elemental Magic'
        and spell.element
        and (is_sch_main or is_sch_sub)
        and arts == 'dark'
        and has_weather(spell.element)
        and not buffactive['Klimaform']
        and abil_recasts[222] and abil_recasts[222] < LATENCY then  -- FIX: was spell_available('Klimaform')

        cancel_spell()
        send_command('input /ja "Klimaform" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)  -- FIX: was /ma
        eventArgs.cancel = true
        return
    end

    -------------------------------------------------------------------------------------------------------------------
    -- SCH: ELEMENTAL STORMS (Elemental Magic — prep matching weather before nuking)
    -- Skips crowd-control spells; they need to land immediately.
    -- Only fires when HP >= 75% (risky to delay when low).
    -- [NEW] Only fires when NOT actively magic bursting — interrupting a burst chain to
    -- cast weather would tank burst timing/DPS. If MagicBurstMode isn't defined on the
    -- current job at all, treats that the same as "off" (safe default, no nil error).
    -------------------------------------------------------------------------------------------------------------------
    local not_bursting = (not state.MagicBurstMode) or state.MagicBurstMode.value == 'Off'

    if spell.skill == 'Elemental Magic'
        and spell.element
        and (is_sch_main or is_sch_sub)
        and player.hpp >= 75
        and not_bursting
        and not has_weather(spell.element)
        and not crowd_control_spells[spell.english] then

        local storm = nil

        if is_sch_main then
            local storms = {
                Fire      = {'Firestorm II',   'Firestorm'},
                Ice       = {'Hailstorm II',   'Hailstorm'},
                Wind      = {'Windstorm II',   'Windstorm'},
                Earth     = {'Sandstorm II',   'Sandstorm'},
                Lightning = {'Thunderstorm II','Thunderstorm'},
                Water     = {'Rainstorm II',   'Rainstorm'},
                Light     = {'Aurorastorm II', 'Aurorastorm'},
                Dark      = {'Voidstorm II',   'Voidstorm'},
            }
            local list = storms[spell.element] or {}
            for _, s in ipairs(list) do
                if spell_available(s) then storm = s; break end
            end
        else
            local storms = {
                Fire='Firestorm', Ice='Hailstorm', Wind='Windstorm',
                Earth='Sandstorm', Lightning='Thunderstorm',
                Water='Rainstorm', Light='Aurorastorm', Dark='Voidstorm',
            }
            local s = storms[spell.element]
            if s and spell_available(s) then storm = s end
        end

        if storm then
            cancel_spell()
            send_command('input /ma "'..storm..'" <me>;wait 1.2;input /ma "'..spell.english..'" '..target)
            eventArgs.cancel = true
            return
        end
    end
end

-------------------------------------------------------------------------------------------------------------------
-- SUBLIMATION AUTOMATION
-- Automatically re-activates Sublimation when the buff drops.
-- Call this from your job file's job_aftercast() and job_buff_change().
-- Only fires for SCH main or sub.
-- Will not fire if: Sublimation is already active, Refresh III is up,
--                   player is mid-action, or Amnesia is active.
-- FIX: Corrected ability recast ID 96 (was 36, which is a completely different ability)
-------------------------------------------------------------------------------------------------------------------
function try_sublimation()
    if player.main_job ~= 'SCH' and player.sub_job ~= 'SCH' then return end

    local now = os.time()
    if now < sublimation_last_check then return end
    sublimation_last_check = now + SUBLIMATION_INTERVAL

    -- Already active — nothing to do
    if buffactive['Sublimation: Activated'] or buffactive['Sublimation: Complete'] then return end

    -- Refresh III is better for MP recovery — don't waste the slot
    if buffactive['Refresh III'] then return end

    -- Don't interrupt casts or fire while silenced/amnesia'd
    if midaction() or buffactive['Amnesia'] or buffactive['Silence'] then return end

    local abil_recasts = windower.ffxi.get_ability_recasts()
    if not abil_recasts then return end

    -- FIX: Sublimation ability recast ID is 96, not 36
    if abil_recasts[96] and abil_recasts[96] < LATENCY then
        send_command('input /ja "Sublimation" <me>')
    end
end

-------------------------------------------------------------------------------------------------------------------
-- BUFF CHANGE HELPER
-- Call this from your job file's job_buff_change() to react to Sublimation falling off.
--
-- Example in your job file:
--   function job_buff_change(buff, gain)
--       smart_caster_buff_change(buff, gain)
--       -- ... rest of your buff_change logic ...
--   end
-------------------------------------------------------------------------------------------------------------------
function smart_caster_buff_change(buff, gain)
    if buff == 'Sublimation: Activated' or buff == 'Sublimation: Complete' then
        try_sublimation()
    end
end

-------------------------------------------------------------------------------------------------------------------
-- !! IMPORTANT — DO NOT ADD job_precast / job_aftercast / job_buff_change HERE !!
--
-- This is an include file. Defining GearSwap hook functions here would silently
-- overwrite the same functions in your job file (Lua last-definition wins).
-- Instead, call the helpers above from your job file's own hook functions.
-------------------------------------------------------------------------------------------------------------------