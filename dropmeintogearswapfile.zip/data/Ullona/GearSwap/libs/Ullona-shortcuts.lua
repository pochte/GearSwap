-------------------------------------------------------------------------------------------------------------------
-- ULLONA'S ULTIMATE SHORTCUTS (FULL BLOWN, GEARSWAP SAFE)
-- No loops, no risk, all typo-resistant + easter eggs hidden
-------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------------------------------
-- MAIN SHORTCUT SETUP FUNCTION
-------------------------------------------------------------------------------------------------------------------
function setup_command_shortcuts()
    -------------------------------------------------------------------------------------------------------------------
    -- MODE SHORTCUTS
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias melee gs c melee')
    send_command('alias ranged gs c ranged')
    send_command('alias caster gs c caster')
    send_command('alias pet gs c pet')
    send_command('alias idle gs c idle')
    send_command('alias dt gs c dt')
    send_command('alias engage gs c engage')
    send_command('alias nuke gs c nuke')
    send_command('alias burst gs c burst')
    send_command('alias kite gs c kite')
    send_command('alias lock gs c lock')
    send_command('alias unlock gs c unlock')

    -------------------------------------------------------------------------------------------------------------------
    -- TELEPORT SHORTCUTS + TYPO VARIATIONS
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias holla input /ma "Teleport-Holla" <me>')
    send_command('alias dem input /ma "Teleport-Dem" <me>')
    send_command('alias mea input /ma "Teleport-Mea" <me>')
    send_command('alias altep input /ma "Teleport-Altep" <me>')
    send_command('alias altap input /ma "Teleport-Altep" <me>') 
    send_command('alias atlap input /ma "Teleport-Altep" <me>') 
    send_command('alias yhoat input /ma "Teleport-Yhoat" <me>')
    send_command('alias vahzl input /ma "Teleport-Vahzl" <me>')
    send_command('alias hell input /ma "Teleport-Yhoat" <me>') 
    send_command('alias vazhl input /ma "Teleport-Vahzl" <me>')
    send_command('alias vaz input /ma "Teleport-Vahzl" <me>')
    send_command('alias vazl input /ma "Teleport-Vahzl" <me>')
    send_command('alias valz input /ma "Teleport-Vahzl" <me>') 
    send_command('alias zhalvl input /ma "Teleport-Vahzl" <me>') 
 

    -------------------------------------------------------------------------------------------------------------------
    -- RECALL SHORTCUTS
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias pash input /ma "Recall-Pashh" <me>')
    send_command('alias pashh input /ma "Recall-Pashh" <me>')
    send_command('alias meri input /ma "Recall-Meriph" <me>')
    send_command('alias jugner input /ma "Recall-Jugner" <me>')
    send_command('alias junger input /ma "Recall-Jugner" <me>')

    -------------------------------------------------------------------------------------------------------------------------------------------------------
-- WARP SHORTCUTS
-------------------------------------------------------------------------------------------------------------------

-- Aliases for all warp commands
send_command('alias warp gs c warp')
send_command('alias return gs c warp')
send_command('alias warp2 gs c warp2')
send_command('alias warpring gs c warpring')
send_command('alias wrp gs c warpring')
send_command('alias wpr gs c warpring')
send_command('alias werp gs c warpring')
send_command('alias wert gs c warpring')
send_command('alias wrpring gs c warpring')
send_command('alias asdf /echo You found the easter egg!')

    -------------------------------------------------------------------------------------------------------------------
    -- BLM SPELL SHORTCUTS
    -------------------------------------------------------------------------------------------------------------------
    --Blizzard--
    send_command('alias bliz input /ma "Blizzard" <t>')
    send_command('alias bliz2 input /ma "Blizzard II" <t>')
    send_command('alias bliz3 input /ma "Blizzard III" <t>')
    send_command('alias bliz4 input /ma "Blizzard IV" <t>')
    send_command('alias bliz5 input /ma "Blizzard V" <t>')
    send_command('alias blizz input /ma "Blizzard" <t>')
    send_command('alias blizz2 input /ma "Blizzard II" <t>')
    send_command('alias blizz3 input /ma "Blizzard III" <t>')
    send_command('alias blizz4 input /ma "Blizzard IV" <t>')
    send_command('alias blizz5 input /ma "Blizzard V" <t>')
    
    send_command('alias ice input /ma "Blizzard" <t>')
    send_command('alias ice2 input /ma "Blizzard II" <t>')
    send_command('alias ice3 input /ma "Blizzard III" <t>')
    send_command('alias ice4 input /ma "Blizzard IV" <t>')
    send_command('alias ice5 input /ma "Blizzard V" <t>')

    send_command('alias icega input /ma "Blizzaga" <t>')
    send_command('alias icega2 input /ma "Blizzaga II" <t>')
    send_command('alias icega3 input /ma "Blizzaga III" <t>')
    send_command('alias icega4 input /ma "Blizzara" <t>')
    send_command('alias icega5 input /ma "Blizzara II" <t>')

    send_command('alias blizga input /ma "Blizzaga" <t>')
    send_command('alias blizga2 input /ma "Blizzaga II" <t>')
    send_command('alias blizga3 input /ma "Blizzaga III" <t>')
    send_command('alias blizga4 input /ma "Blizzara" <t>')
    send_command('alias blizga5 input /ma "Blizzara II" <t>')

    --Aero--
    send_command('alias Airo input /ma "Aero" <t>')
    send_command('alias Airo2 input /ma "Aero II" <t>')
    send_command('alias Airo3 input /ma "Aero III" <t>')
    send_command('alias Airo4 input /ma "Aero IV" <t>')
    send_command('alias Airo5 input /ma "Aero V" <t>')
    send_command('alias Aero input /ma "Aero" <t>')
    send_command('alias Aero2 input /ma "Aero II" <t>')
    send_command('alias Aero3 input /ma "Aero III" <t>')
    send_command('alias Aero4 input /ma "Aero IV" <t>')
    send_command('alias Aero5 input /ma "Aero V" <t>')

    -- [FIX] Letter-swap typo coverage (areo instead of aero) — same targets as Aero above
    send_command('alias areo input /ma "Aero" <t>')
    send_command('alias areo2 input /ma "Aero II" <t>')
    send_command('alias areo3 input /ma "Aero III" <t>')
    send_command('alias areo4 input /ma "Aero IV" <t>')
    send_command('alias areo5 input /ma "Aero V" <t>')
    
    send_command('alias wind input /ma "Aero" <t>')
    send_command('alias wind2 input /ma "Aero II" <t>')
    send_command('alias wind3 input /ma "Aero III" <t>')
    send_command('alias wind4 input /ma "Aero IV" <t>')
    send_command('alias wind5 input /ma "Aero V" <t>')
    send_command('alias air input /ma "Aero" <t>')
    send_command('alias air2 input /ma "Aero II" <t>')
    send_command('alias air3 input /ma "Aero III" <t>')
    send_command('alias air4 input /ma "Aero IV" <t>')
    send_command('alias air5 input /ma "Aero V" <t>')

    -- [FIX] Removed the duplicate 'Aero'/'Aero2'-'Aero5' block that used to sit here pointing
    -- at Aeroaga/Aeroara — it silently overwrote the single-target Aero aliases defined above,
    -- so typing "Aero" was actually casting Aeroaga this whole time. AoE versions now live
    -- only under Airoga/Aeroga/areoga below, so single-target Aero behaves like every other
    -- single-target alias in this file.
    send_command('alias Airoga input /ma "Aeroaga" <t>')
    send_command('alias Airoga2 input /ma "Aeroaga II" <t>')
    send_command('alias Airoga3 input /ma "Aeroaga III" <t>')
    send_command('alias Airoga4 input /ma "Aeroara" <t>')
    send_command('alias Airoga5 input /ma "Aeroara II" <t>')

    -- [FIX] Added Aeroga/areoga families to match the icega/blizga dual-naming pattern
    -- already used for Blizzard, plus the areo letter-swap typo for the AoE tier too.
    send_command('alias Aeroga input /ma "Aeroaga" <t>')
    send_command('alias Aeroga2 input /ma "Aeroaga II" <t>')
    send_command('alias Aeroga3 input /ma "Aeroaga III" <t>')
    send_command('alias Aeroga4 input /ma "Aeroara" <t>')
    send_command('alias Aeroga5 input /ma "Aeroara II" <t>')

    send_command('alias areoga input /ma "Aeroaga" <t>')
    send_command('alias areoga2 input /ma "Aeroaga II" <t>')
    send_command('alias areoga3 input /ma "Aeroaga III" <t>')
    send_command('alias areoga4 input /ma "Aeroara" <t>')
    send_command('alias areoga5 input /ma "Aeroara II" <t>')
    -------------------------------------------------------------------------------------------------------------------
    -- CURE SHORTCUTS
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias c input /ma "Cure" <t>')
    send_command('alias c2 input /ma "Cure II" <t>')
    send_command('alias c3 input /ma "Cure III" <t>')
    send_command('alias c4 input /ma "Cure IV" <t>')
    send_command('alias c5 input /ma "Cure V" <t>')
    send_command('alias c6 input /ma "Cure VI" <t>')

    -------------------------------------------------------------------------------------------------------------------
    -- RAISE / RERAISE
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias rr input /ma "Reraise" <me>')
    send_command('alias rr2 input /ma "Reraise II" <me>')
    send_command('alias rr3 input /ma "Reraise III" <me>')
    send_command('alias rr4 input /ma "Reraise IV" <me>')
    send_command('alias r input /ma "Raise" <st>')
    send_command('alias r2 input /ma "Raise II" <st>')
    send_command('alias r3 input /ma "Raise III" <st>')
    send_command('alias arize input /ma "Arise" <st>')
    send_command('alias arise input /ma "Arise" <st>')
    send_command('alias arz input /ma "Arise" <st>')
    send_command('alias ars input /ma "Arise" <st>')
    send_command('alias r4 ars input /ma "Arise" <st>')

    -------------------------------------------------------------------------------------------------------------------
    -- CURAGA SHORTCUTS
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias cga input /ma "Curaga" <t>')
    send_command('alias cga2 input /ma "Curaga II" <t>')
    send_command('alias cga3 input /ma "Curaga III" <t>')
    send_command('alias cga4 input /ma "Curaga IV" <t>')
    send_command('alias cga5 input /ma "Curaga V" <t>')

    -------------------------------------------------------------------------------------------------------------------
    -- SLEEP / SLEEPGA / TYPO VARIATIONS
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias z input /ma "Sleep" <stnpc>')
    send_command('alias z2 input /ma "Sleep II" <stnpc>')
    send_command('alias zz input /ma "Sleep" <stnpc>')
    send_command('alias zz2 input /ma "Sleep II" <stnpc>')
    send_command('alias zzz input /ma "Sleep" <stnpc>')
    send_command('alias zzz2 input /ma "Sleep II" <stnpc>')
    send_command('alias zzzz input /ma "Sleep II" <stnpc>')
    send_command('alias zzzzz input /ma "Sleep II" <stnpc>')

    -- Sleepga variations
    send_command('alias zga input /ma "Sleepga" <t>')
    send_command('alias zga2 input /ma "Sleepga II" <t>')
    send_command('alias zzga input /ma "Sleepga" <t>')
    send_command('alias zzga2 input /ma "Sleepga II" <t>')
    send_command('alias zzzga input /ma "Sleepga" <t>')
    send_command('alias zzzga2 input /ma "Sleepga II" <t>')
    send_command('alias zzzzga input /ma "Sleepga II" <t>')

    -- Common typo coverage
    send_command('alias slpga input /ma "Sleepga" <t>')
    send_command('alias slpga2 input /ma "Sleepga II" <t>')
    send_command('alias sleepaga input /ma "Sleepga" <t>')
    send_command('alias sleepaga2 input /ma "Sleepga II" <t>')
    send_command('alias slpaga input /ma "Sleepga" <t>')
    send_command('alias slpaga2 input /ma "Sleepga II" <t>')

    -------------------------------------------------------------------------------------------------------------------
    -- BREAK / BIND / GRAVITY
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias brk input /ma "Break" <stnpc>')
    send_command('alias brkga input /ma "Breakga" <t>')
    send_command('alias bnd input /ma "Bind" <stnpc>')
    send_command('alias grav input /ma "Gravity" <stnpc>')
    send_command('alias grav2 input /ma "Gravity II" <stnpc>')

    -------------------------------------------------------------------------------------------------------------------
    -- RDM / BUFFS / TYPO VARIATIONS
    -------------------------------------------------------------------------------------------------------------------
    -- Composure
    send_command('alias rdmbuff /ja "Composure" <me>')
    send_command('alias comp /ja "Composure" <me>')
    send_command('alias compo /ja "Composure" <me>')
    send_command('alias compos /ja "Composure" <me>')
    send_command('alias compsoer /ja "Composure" <me>')

    -- Saboteur
    send_command('alias sabo /ja "Saboteur" <me>')
    send_command('alias sab /ja "Saboteur" <me>')
    send_command('alias saboteur /ja "Saboteur" <me>')
    send_command('alias saboer /ja "Saboteur" <me>')

    -- Spontaneity
    send_command('alias spnt /ja "Spontaneity" <me>')
    send_command('alias spont /ja "Spontaneity" <me>')
    send_command('alias spy /ja "Spontaneity" <me>')
    send_command('alias spon /ja "Spontaneity" <me>')
    send_command('alias sp /ja "Spontaneity" <me>')
    send_command('alias sponte /ja "Spontaneity" <me>')

    -- Stymie
    send_command('alias sty /ja "Stymie" <me>')
    send_command('alias st /ja "Stymie" <me>')
    send_command('alias stymi /ja "Stymie" <me>')
    send_command('alias stmi /ja "Stymie" <me>')
    send_command('alias stme /ja "Stymie" <me>')
    send_command('alias stmy /ja "Stymie" <me>')

    -------------------------------------------------------------------------------------------------------------------
    -- BAR / SEAL / SNEAK / INVIS
    -------------------------------------------------------------------------------------------------------------------
    send_command('alias bpara /ma "Barparalyzra" <me>')
    send_command('alias es /ja "Elemental Seal" <me>')
    send_command('alias ds /ja "Divine Seal" <me>')
    send_command('alias snk /ma "Sneak" <t>')
    send_command('alias invis /ma "Invisible" <t>')
    

end

-------------------------------------------------------------------------------------------------------------------
-- FFXIV /l1 REDIRECT (Event Handler)
-------------------------------------------------------------------------------------------------------------------
windower.register_event('outgoing text', function(original, modified, blocked)
    if original and original:lower():match('^/l1%s') then
        local message = original:match('^/l1%s+(.*)$')
        if message then
            windower.send_command('input /l ' .. message)
            return true
        end
    end
    return false
end)

-------------------------------------------------------------------------------------------------------------------
-- MULTI-SLASH COMMAND FIX (accepts //, ///, ////, etc. before ANY command/alias)
-- Windower treats a leading "//" as an escape that TYPES a literal slash into chat instead
-- of running the command — that's why //warp never actually fired, it just said "/warp"
-- out loud. This catches 2+ leading slashes on anything and re-fires it as a real command,
-- so mashing extra slashes (on warp or any other alias) now behaves the same as one slash.
-------------------------------------------------------------------------------------------------------------------
windower.register_event('outgoing text', function(original, modified, blocked)
    local slashes, rest = original:match('^(/+)(%S.*)$')
    if slashes and #slashes >= 2 and rest then
        windower.send_command('input /' .. rest)
        return true
    end
    return false
end)

-------------------------------------------------------------------------------------------------------------------
-- FFXI Macro Book Keybinds (Windows key + 1-0)
-- This is bound to WINDOWS key. You need to make sure it is enabled. Or shit will break.
-------------------------------------------------------------------------------------------------------------------



-------------------------------------------------------------------------------------------------------------------
-- AUTO-INITIALIZE
-------------------------------------------------------------------------------------------------------------------
setup_command_shortcuts()


-------------------------------------------------------------------------------------------------------------------