-- Setup vars that are user-dependent.  Can override this function in a sidecar file.
function user_job_setup()
	-- Options: Override default values
    state.OffenseMode:options('Normal','SomeAcc','Acc','FullAcc','Fodder')
    state.HybridMode:options('Normal','DT')
    state.RangedMode:options('Normal', 'Acc')
    state.WeaponskillMode:options('Match','Normal','DT','SomeAcc','Acc','FullAcc','Fodder','Proc')
	state.IdleMode:options('Normal', 'Sphere')
    state.PhysicalDefenseMode:options('PDT')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
	state.Weapons:options('Aeneas','Aeolian','Savage','ProcWeapons','Evisceration','Throwing','SwordThrowing','Bow')

    state.ExtraMeleeMode = M{['description']='Extra Melee Mode','None','Suppa','DWMax','Parry'}
	state.AmbushMode = M(false, 'Ambush Mode')

	gear.da_jse_back = {name="Toutatis's Cape", augments={'DEX+20','Accuracy+20 Attack+20','"Dbl.Atk."+10',}}
	gear.wsd_jse_back = {name="Toutatis's Cape", augments={'DEX+20','Accuracy+20 Attack+20','Weapon skill damage +10%',}}

	-- Additional local binds
	send_command('bind ^` input /ja "Flee" <me>')                 -- Ctrl + `         : Flee on self (increases movement speed)
	send_command('bind !` input /ra <t>')                         -- Alt + `          : Perform a ranged attack on current target
	send_command('bind @` gs c cycle SkillchainMode')             -- Win + `          : Cycle SkillchainMode (Off/Auto/etc.)
	send_command('bind @f10 gs c toggle AmbushMode')              -- Win + F10        : Toggle AmbushMode (uses Ambush positioning gear)
	send_command('bind ^backspace input /item "Thief\'s Tools" <t>') -- Ctrl + Backspace : Use Thief's Tools on current target (lockpicking)
	send_command('bind ^q gs c weapons ProcWeapons;gs c set WeaponSkillMode proc;') -- Ctrl + Q : Equip ProcWeapons and set WeaponSkillMode to Proc
	send_command('bind !q gs c weapons SwordThrowing')            -- Alt + Q          : Equip Sword/Throwing weapon set
	send_command('bind !backspace input /ja "Hide" <me>')         -- Alt + Backspace  : Hide on self (drops aggro / stealth)
	send_command('bind @r gs c weapons Default;gs c set WeaponSkillMode match') -- Win + R : Equip Default weapons and set WeaponSkillMode to Match
	send_command('bind !r gs c weapons MagicWeapons')             -- Alt + R          : Equip MagicWeapons set
	send_command('bind ^\\\\ input /ja "Despoil" <t>')            -- Ctrl + \         : Despoil current target (attempt to steal an item and inflict a debuff)
	send_command('bind !\\\\ input /ja "Mug" <t>')                -- Alt + \          : Mug current target (steal gil and deal damage)

    select_default_macro_book()
end

-- Define sets and vars used by this job file.
function init_gear_sets()
    --------------------------------------
    -- Special sets (required by rules)
    --------------------------------------

	sets.TreasureHunter = {hands="Plunderer's Armlets +1", feet="Skulker's Poulaines +1", waist="Chaac Belt"}
    sets.Kiting = {feet="Pillager's Poulaines +1"}

	sets.buff.Doom = set_combine(sets.buff.Doom, {})
	sets.buff.Sleep = {}
	
    sets.buff['Sneak Attack'] = {hands="Skulker's Armlets +1", back="Toutatis's Cape"}
    sets.buff['Trick Attack'] = {back="Toutatis's Cape", hands="Pillager's Armlets +1"}

    -- Extra Melee sets.  Apply these on top of melee sets.
    sets.Knockback = {}
	sets.Suppa = {}
	sets.DWEarrings = {}
	sets.DWMax = {}
	sets.Parry = {}
	sets.Ambush = {}
	
	-- Weapons sets
	sets.weapons.Aeneas = {}
	sets.weapons.Aeolian = {}
	sets.weapons.Savage = {}
	sets.weapons.ProcWeapons = {}
	sets.weapons.Evisceration = {}
	sets.weapons.Throwing = {}
	sets.weapons.SwordThrowing = {}
	sets.weapons.Bow = {}
	
    -- Actions we want to use to tag TH.
    sets.precast.Step = {
        head="Mummu Bonnet +2",              
        neck="Love Torque",              
        ear1="Cessance Earring",          
        ear2="Sherida Earring",            
        body="Mummu Jacket +2",             
        hands="Leyline Gloves",         
        ring1="Mars's  Ring",             
        ring2="Iota Ring",              
        back="Toutatis's Cape",       
        waist="Sailfi Belt",             
        legs="SV loincloth +1",          
        feet="Plunderer's Poulaines"
    }
		
    sets.precast.JA['Violent Flourish'] = {}
	sets.precast.JA['Animated Flourish'] = sets.TreasureHunter
	sets.precast.JA.Provoke = sets.TreasureHunter

    --------------------------------------
    -- Precast sets
    --------------------------------------

    -- Precast sets to enhance JAs
    sets.precast.JA['Collabolua lotor'] = {head="Skulker's Bonnet"}
    sets.precast.JA['Accomplice'] = {head="Skulker's Bonnet"}
    sets.precast.JA['Flee'] = {feet="Pillager's Poulaines +1",}
    sets.precast.JA['Hide'] = {body="Pillager's Vest +1"}
    sets.precast.JA['Conspirator'] = {head="Skulker's Bonnet", body="Skulker's Vest", hands="Skulker's Armlets +1", legs="Skulker's Culottes +1", feet="Skulker's Poulaines +1"} 
    sets.precast.JA['Steal'] = {legs="Pillager's Culottes +1", feet="Pillager's Poulaines +1", hands="Pillager's Armlets +1"}
	sets.precast.JA['Mug'] = {head="Plunderer's Bonnet"}
    sets.precast.JA['Despoil'] = {feet=" Skulker's Poulaines +1", legs="Skulker's Culottes +1"}
    sets.precast.JA['Perfect Dodge'] = {hands="Plunderer's Armlets +1"}
    sets.precast.JA['Feint'] = {legs="Plunderer's Culottes +1"}

    sets.precast.JA['Sneak Attack'] = sets.buff['Sneak Attack']
    sets.precast.JA['Trick Attack'] = sets.buff['Trick Attack']

    -- Waltz set (chr and vit)
    sets.precast.Waltz = {}
	sets.Self_Waltz = {}
    sets.precast.Waltz['Healing Waltz'] = {}

    -- Fast cast sets for spells
    sets.precast.FC = {    
        head="Ejekamal Mask",           
        ear1="Loquacious Earring",   
        ear2="Malignance Earring",   
        body="Skulker's Vest",         
        hands="Leyline Gloves",     
        waist="Sailfi Belt",
        feet="Mummu Gameshes +2",
        legs="Malignance Tights",
        ring2="Murky Ring",
        neck = "Voltsurge Torque",
        ring1="Lebeche Ring"
    }

    sets.precast.FC.Utsusemi = set_combine(sets.precast.FC, {neck="Magoraga Bead Necklace"})

    -- Ranged snapshot gear
    sets.precast.RA = {}

    --------------------------------------
    -- Weaponskill sets
    --------------------------------------

    -- Default set for any weaponskill that isn't more specifically defined
    sets.precast.WS = {    
        head="Sukeroku Hachimaki",          
        neck="Fiota Gorget",            
        ear1="Ishvara Earring",           
        ear2="Sherida Earring",           
        body="Malignance Tabard",           
        hands="Meghanada Gloves +2",       
        ring2="Mujin Band",             
        ring1="Mars's Ring",               
        back="Toutatis's Cape",       
        waist="Fotia Belt",              
        legs="Malignance Tights",          
        feet="Meghanada Jambeaux +2"
    }
    
    sets.precast.WS.SomeAcc = set_combine(sets.precast.WS, {
        hands="Leyline Gloves",         
        ring1="Mars's Ring",  
        ring2="Meghanada Ring",                                   
        waist="Fotia Belt",
        legs="Malignance Tights"
    })
    
    sets.precast.WS.Acc = set_combine(sets.precast.Step, {})
	sets.precast.WS.FullAcc = set_combine(sets.precast.Step, {})



	-- Swap to these on Moonshade using WS if at 3000 TP
	sets.MaxTP = {}
	sets.AccMaxTP = {}

    --------------------------------------
    -- Midcast sets
    --------------------------------------

    sets.midcast.FastRecast = {}

    -- Specific spells
	sets.midcast.Utsusemi = set_combine(sets.midcast.FastRecast, {neck="Magoraga Bead Necklace"})

    -- Ranged gear
    sets.midcast.RA = {}
    sets.midcast.RA.Acc = {}

    --------------------------------------
    -- Melee sets — MUST be defined before sets.idle, which combines onto sets.engaged
    --------------------------------------

    -- [FIX 1]: This whole block was previously located AFTER sets.idle, but sets.idle
    --          references sets.engaged via set_combine — meaning set_combine(nil, {...})
    --          was thrown at load time (sets.engaged didn't exist yet), which aborted
    --          the entire file mid-load. That's why "no gear set exists" — nothing after
    --          the crash point ever ran. Moved up here so it's defined first.
    --
    -- [FIX 2]: Tiers now cascade properly (RDM-style) — each tier builds ON TOP of the
    --          previous one via set_combine, so FullAcc actually keeps Acc's gear plus
    --          its own additions, rather than each tier separately re-deriving from base
    --          and losing whatever the tier below it had. DT variants likewise combine
    --          onto their OWN tier (SomeAcc.DT keeps SomeAcc's gear + DT bonus), not just
    --          onto the bare base set.
    -- [FIX 3]: Skulker's Earring (THF-only) only procs its Triple Attack+3%/Subtle Blow+5
    --          when worn in the RIGHT ear (ear2) — confirmed via in-game tooltip. Since
    --          Sherida Earring has no ear restriction, swapped the two: Sherida now sits
    --          in ear1 (keeps its DA+5%/StoreTP+5/Subtle Blow II+5/STR+DEX intact) and
    --          Skulker's takes ear2, netting Triple Attack+3% on top vs. the old Cessance
    --          ear1 (Acc+6/DA+3%/StoreTP+3), which is now dropped from this base tier.
    sets.engaged = {    
        head="Meghanada Visor +2",
        neck="Anu Torque",           
        ear1="Sherida Earring",           
        ear2="Skulker's Earring",           
        body="Malignance Tabard",            
        hands="Malignance Gloves",       
        ring1="Mars's Ring",             
        ring2="Rajas Ring",              
        back="Toutatis's Cape",          
        waist="Sailfi Belt",            
        legs="Malignance Tights",       
        feet="Mummy Gamashes +2"
    }
		
    sets.engaged.SomeAcc = set_combine(sets.engaged, {waist=gear.default.waist, neck="Sanctity Necklace", ear1="Cessance Earring"})
	sets.engaged.Acc = set_combine(sets.engaged.SomeAcc, {neck="Null Loop"})
    -- [FIX 2 cont.]: was set_combine(sets.Acc, ...) — sets.Acc never existed (typo for
    --          sets.engaged.Acc), so this branch was silently equipping a table missing
    --          everything SomeAcc/Acc had contributed. Now correctly builds on Acc.
    sets.engaged.FullAcc = set_combine(sets.engaged.Acc, {ring1="Mars's Ring", ear1="Cessance Earring"})
    sets.engaged.Fodder = set_combine(sets.engaged, {back="Null Cape"})

    sets.engaged.DT = set_combine(sets.engaged, {})
    sets.engaged.SomeAcc.DT = set_combine(sets.engaged.SomeAcc, {})
    sets.engaged.Acc.DT = set_combine(sets.engaged.Acc, {})
    sets.engaged.FullAcc.DT = set_combine(sets.engaged.FullAcc, {})
    sets.engaged.Fodder.DT = set_combine(sets.engaged.Fodder, {})

    --------------------------------------
    -- Idle/resting/defense sets
    --------------------------------------

    -- Resting sets
    sets.resting = {}

    -- Idle sets
    sets.idle = set_combine(sets.engaged, {
        feet="Pillager's Poulaines +1",
        hands="Umulthi Gloves",
        waist="Null Belt"
    })
		
    sets.idle.Sphere = set_combine(sets.idle, {waist="Null Belt"})
    sets.idle.Weak = set_combine(sets.idle, {})

	sets.DayIdle = set_combine(sets.idle, {})
	sets.NightIdle = set_combine(sets.idle, {})

	sets.ExtraRegen = set_combine(sets.idle, {waist="Null Belt"})


    -- Defense sets
    sets.defense.PDT = {

    }

    sets.defense.MDT = {

    }
		
	sets.defense.MEVA = {}
end
-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
	set_macro_page(1, 6)
end

function user_job_lockstyle()
    -- Delay is necessary for game to finish loading equipment model
    send_command('input /lockstyleset 5')
end