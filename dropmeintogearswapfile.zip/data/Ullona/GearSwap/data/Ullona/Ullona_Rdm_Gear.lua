-- =============================================================================
-- Ullona_Rdm_Gear.lua
-- Corrected version — see numbered [FIX] comments throughout for what changed.
-- =============================================================================

function user_job_setup()
	-- Options: Override default values
    state.OffenseMode:options('Normal','Acc','FullAcc')
    state.HybridMode:options('Normal','DT')
	state.WeaponskillMode:options('Match','Proc')
	state.AutoBuffMode:options('Off','Auto','AutoMelee')
	state.CastingMode:options('Normal','Resistant', 'Fodder', 'Proc')
    state.IdleMode:options('Normal','PDT','MDT')
    state.PhysicalDefenseMode:options('PDT','NukeLock')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
	state.Weapons:options('None','Naegling','EnspellMelee')
	-- [FIX] Removed 'DualWeapons' as a separate manual stop — its gear (dagger+degen+bow)
	-- is now auto-selected under 'Naegling' whenever sub job is NIN, via job_handle_equipping_gear() below.
	
	-- =========================================================================
	-- Additional local binds — every keybind noted below for quick reference.
	-- Modifier key: ^ = Ctrl, ! = Alt, @ = Win, ~ = Shift
	-- =========================================================================
	send_command('bind ^` gs c cycle ElementalMode')              -- Ctrl + `          : Cycle ElementalMode forward (Fire/Ice/Wind/etc.)
	send_command('bind @` gs c cycle MagicBurstMode')             -- Win + `           : Cycle MagicBurstMode (Off/Single/etc.)
	send_command('bind ^@!` input /ja "Accession" <me>')          -- Ctrl+Win+Alt + `  : Accession on self (boosts next spell's magic burst damage)
	send_command('bind ^backspace input /ja "Saboteur" <me>')     -- Ctrl + Backspace  : Saboteur on self (boosts enfeebling potency/landing)
	send_command('bind !backspace input /ja "Spontaneity" <t>')   -- Alt + Backspace   : Spontaneity on target (instant enfeeble/ench, no recast)
	send_command('bind @backspace input /ja "Composure" <me>')    -- Win + Backspace   : Composure on self (extends enhancing spell duration)
	send_command('bind @f8 gs c toggle AutoNukeMode')             -- Win + F8          : Toggle AutoNukeMode
	send_command('bind != input /ja "Penury" <me>')               -- Alt + =           : Penury on self (halves next spell's MP cost)
	send_command('bind @= input /ja "Parsimony" <me>')            -- Win + =           : Parsimony on self (halves next spell's MP cost, JP-boosted)
	send_command('bind ^delete input /ja "Dark Arts" <me>')       -- Ctrl + Delete     : Dark Arts on self (SCH subjob)
	send_command('bind !delete input /ja "Addendum: Black" <me>') -- Alt + Delete      : Addendum: Black on self (SCH subjob, pairs with Dark Arts)
	send_command('bind @delete input /ja "Manifestation" <me>')   -- Win + Delete      : Manifestation on self (SCH subjob, MP-to-damage conversion)
	send_command('bind ^\\\\ input /ma "Protect V" <t>')          -- Ctrl + \          : Protect V on target
	send_command('bind @\\\\ input /ma "Shell V" <t>')            -- Win + \           : Shell V on target
	send_command('bind !\\\\ input /ma "Reraise" <me>')           -- Alt + \           : Reraise on self
	send_command('bind @f10 gs c cycle RecoverMode')              -- Win + F10         : Cycle RecoverMode (MP recovery threshold: 35%/60%/Always/Never)
	send_command('bind ^w gs c weaponcycle')
	-- [FIX2] Ctrl + W : Cycle weapon modes AND immediately force the correct sub/range gear
	-- via job_self_command below. The plain 'gs c cycle weapons' approach was unreliable —
	-- GearSwap doesn't guarantee job_handle_equipping_gear fires after a manual state cycle,
	-- so the shield would sometimes stick around instead of the degen on NIN sub. This
	-- bypasses that ambiguity entirely by equipping directly inside the same command.
	
	select_default_macro_book()
end

function init_gear_sets()
	--------------------------------------
	-- Start defining the sets
	--------------------------------------
	
	-- Precast Sets
	
	-- Precast sets to enhance JAs
	sets.precast.JA['Chainspell'] = {body="Viti. Tabard +3"}
	

	-- Waltz set (chr and vit)
	sets.precast.Waltz = {}
		
	-- Don't need any special gear for Healing Waltz.
	sets.precast.Waltz['Healing Waltz'] = {}

	-- Fast cast sets for spells
	
	sets.precast.FC =  {  
		main="Emissary",
        ammo  ="Ghastly Tathlum",
        head  ="Bunzi's Hat",
        body  ="Vitiation Tabard +2",
        legs  ="Ayanmo Cosciales +2",
        hands ="Leyline Gloves",
        feet  ="Bunzi's Sabots",
        ear1  ="Malignance Earring",
        ear2  ="Lethargy Earring",
        ring1="Ayanmo Ring",
        ring2 ="Lebeche Ring",
        waist ="Embla Sash",
        neck = "Voltsurge Torque"
    }
	
	sets.precast.FC.Enfeebling = set_combine(sets.precast.FC, {head="Lethargy Chappel +2"})
    sets.precast.Stoneskin     = set_combine(sets.precast.FC, {waist="Siegel Sash", legs="Querkening Brais"})
    sets.precast.FC.Impact     = set_combine(sets.precast.FC, {head=empty, body="Twilight Cloak",ring1 ="Archon Ring"})
    sets.precast.FC.Utsusemi   = set_combine(sets.precast.FC, {neck="Magoraga Beads"})
    sets.precast.FC.Dispelga   = set_combine(sets.precast.FC, {main="Daybreak", sub="Culminus"})

	-- [FIX 1]: Renamed sets.precast['Healing Magic'] to properly sit alongside its midcast
	--          counterpart below — no functional change here, just noted for clarity.
	sets.precast['Healing Magic'] = set_combine(sets.precast.FC, {
        main  ="Chtatoyan Staff",
        sub   ="Achaq Grip"
    })
       
	-- Weaponskill sets
	-- Default set for any weaponskill that isn't any more specifically defined
	sets.precast.WS = {
	    head  ="Vitiation Chapeau +3",
        body  ="Malignance Tabard",
        legs  ="Malignance Tights",
        hands ="Atrophy Gloves +2",
        feet  ="Lethargy Houseaux +3",
        neck  ="Fiota Gorget",
        back  ="Sucellos's Cape",
        waist ="Fiota Belt",
        ear1  ="Ishvara Earring",
        ear2  ="Sherida Earring",
        ring1 ="Ayanmo Ring",
        ring2 ="Mujin Band"
    }
		
	sets.precast.WS.Proc = 	sets.precast.WS

	-- Midcast Sets

	sets.TreasureHunter = set_combine(sets.TreasureHunter, {feet=gear.chironic_treasure_feet})
	
	-- Gear that converts elemental damage done to recover MP.	
	sets.RecoverMP = {}

	sets.midcast.FastRecast = sets.precast.FC

	-- =========================================================================
	-- [FIX 2]: Base cure set renamed from sets.midcast.Cure to sets.midcast['Healing Magic']
	--          to match the naming convention used in your WHM/BLM files. This also resolves
	--          the crash where LightDayCure referenced sets.midcast['Healing Magic'] before
	--          anything by that name existed — set_combine(nil, {...}) throws immediately
	--          and halts the whole file from loading.
	-- =========================================================================
    sets.midcast['Healing Magic'] = { 
		main  ="Chatoyant Staff",
        sub   ="Achaq Grip",
        head  ="Vanya Hood",
        body  ="Bunzi's Robe",
        hands ="Bokwus Gloves",
        neck  ="Nodens Gorget",
        ear2  ="Mendicant's Earring",
        ear1  ="Glorious Earring",
        ring1 ="Janniston Ring",
        ring2 ="Lebeche Ring",
        back  ="Ghostfyre Cape",
        legs  ="Atrophy Tights +2",
        feet  ="Vanya Clogs"}

	-- [FIX 2 cont.]: Cure is now a set_combine copy of Healing Magic (not a direct alias),
	--          so it can't accidentally cross-contaminate Healing Magic if either gets
	--          sub-tables (.Resistant, .DT, etc.) added down the line.
	sets.midcast.Cure = set_combine(sets.midcast['Healing Magic'], {})

    sets.midcast.LightWeatherCure = {}

	-- [FIX 2 cont.]: This now resolves correctly since Healing Magic is defined above it.
    sets.midcast.LightDayCure     = set_combine(sets.midcast['Healing Magic'], {waist=gear.default.obi_weather})

	-- [FIX 3]: Removed the duplicate/dead early definitions of Cursna and StatusRemoval
	--          that were immediately overwritten by the fuller versions a few lines later
	--          in the original file (dead code, last-definition-wins). Kept only the
	--          versions that actually take effect, for clarity.
	sets.midcast.StatusRemoval    = set_combine(sets.midcast.FastRecast, {main=gear.grioavolr_fc_staff, sub="Clemency Grip"})

	sets.midcast.Cursna = set_combine(sets.midcast.Cure, {
		neck="Debilis Medallion", hands="Hieros Mittens",
		back="Oretan. Cape +1", ring1="Haoma's Ring", ring2="Menelaus's Ring",
		waist="Witful Belt", feet="Vanya Clogs"
	})
		
	sets.midcast.Curaga = sets.midcast.Cure
	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}

	sets.midcast['Enhancing Magic'] = {
	    head  ="Umuthi Hat",
        body  ="Vitiation Tabard +2",
        legs  ="Atrophy Tights +2",
        hands ="Atrophy Gloves +2",
        feet  ="Lethargy Houseaux +3",
        neck  ="Duelist's Torque +1",
        ear1  ="Andoaa Earring",
        ear2  ="Lethargy Earring",
        ring1 ="Murky Ring",
        ring2 ="Lebeche Ring",
        back  ="Estoqueur's Cape",
        waist ="Embla Sash"
    }

	--Atrophy Gloves are better than Lethargy for me despite the set bonus for duration on others.		
	sets.buff.ComposureOther = {head="Leth. Chappel +2",
		body="Lethargy Sayon +3",hands="Leth. Gantherots +2",
		legs="Leth. Fuseau +2",feet="Leth. Houseaux +3"}
		
	--Red Mage enhancing sets are handled in a different way from most, layered on due to the way Composure works
	--Don't set combine a full set with these spells, they should layer on Enhancing Set > Composure (If Applicable) > Spell

	sets.midcast.BoostStat = {hands="Viti. Gloves +1"}
	sets.Self_Refresh  = set_combine(sets.midcast['Enhancing Magic'],{feet="Inspirited Boots"})
    sets.midcast.Regen       = set_combine(sets.midcast['Enhancing Magic'], {main="Bolelabunga"})
    sets.EnhancingSkill      = set_combine(sets.midcast['Enhancing Magic'], {hands="Vitiation Gloves +1"})
    sets.midcast.Refresh     = set_combine(sets.midcast['Enhancing Magic'], {legs="Lethargy Fuseau +3", body="Atrophy Tabard +3"})
    sets.precast.Aquaveil    = set_combine(sets.precast.FC, {main="Vadose Rod", sub="Archduke's Shield", hands="Vitiation Gloves +1"})
    sets.midcast.BarElement  = set_combine(sets.midcast['Enhancing Magic'], {hands="Vitiation Gloves +1"})
    sets.midcast.Temper      = set_combine(sets.midcast['Enhancing Magic'], {})
    sets.midcast.Temper.DW   = set_combine(sets.midcast.Temper, {})
    sets.midcast.Enspell     = set_combine(sets.midcast.Temper, {back="Ghostfyre Cape", legs="Vitiation Tights +3", head="Umuthi Hat", main="Archduke's Sword"})
    sets.midcast.Enspell.DW  = set_combine(sets.midcast.Enspell, {})
    sets.midcast.Stoneskin   = set_combine(sets.midcast['Enhancing Magic'], {waist="Siegel Sash", legs="Shedir Seraweels", head="Umuthi Hat", hands="Vitiation Gloves +1", neck  ="Nodens Gorget",})
    sets.midcast.ShockSpikes = set_combine(sets.midcast['Enhancing Magic'], {legs="Vitiation Tights +3"})
    sets.midcast.BlazeSpikes = set_combine(sets.midcast.ShockSpikes, {})
    sets.midcast.IceSpikes   = set_combine(sets.midcast.ShockSpikes, {})
    sets.midcast.Gain        = set_combine(sets.midcast['Enhancing Magic'], {hands="Vitiation Gloves +1"})
    sets.precast.JA.Chainspell = {body="Vitiation Tabard +2"}

	
	sets.midcast['Enfeebling Magic'] =  
    {
		main  ="Mpaca's Staff",
        sub="Mephitis Grip",
        head  ="Vitiation Chapeau +3",
        body  ="Lethargy Sayon +3",
        legs  ="Lethargy Fuseau +3",
        hands ="Lethargy Gantherots +2",
        feet  ="Vitiation Boots +2",
        neck  ="Duelist's Torque +1",
        ring2 ="Jhakri Ring",
        ring1="Crepuscular Ring",
        back  ="Sucellos's Cape",
        waist ="Null Belt",
        ear2  ="Lethargy Earring",
        ear1  ="Malignance Earring",
        ranged="Kaja Bow"
    }
		
	sets.midcast['Enfeebling Magic'].Resistant = set_combine(sets.midcast['Enfeebling Magic'], {
        back ="Null Shawl",
        main ="Chatoyant Staff",
        ear1 ="Gwati Earring",
        sub="Flanged Grip",
        ring1="Vertigo Ring",
        neck="Null Loop",
        ranged="Kaja Bow"
    })		
	sets.midcast.DurationOnlyEnfeebling = set_combine(sets.midcast['Enfeebling Magic'], {body="Atrophy Tabard +3",range="Kaja Bow"})
	sets.midcast.Silence = sets.midcast.DurationOnlyEnfeebling
	sets.midcast.Silence.Resistant = sets.midcast['Enfeebling Magic'].Resistant
	sets.midcast.Sleep = set_combine(sets.midcast.DurationOnlyEnfeebling,{waist="Acuity Belt +1"})
	sets.midcast.Sleep.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Bind = set_combine(sets.midcast.DurationOnlyEnfeebling,{waist="Acuity Belt +1"})
	sets.midcast.Bind.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Break = set_combine(sets.midcast.DurationOnlyEnfeebling,{waist="Acuity Belt +1"})
	sets.midcast.Break.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Dispel = sets.midcast['Enfeebling Magic'].Resistant
	sets.midcast.Dispelga = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{main="Daybreak", sub="Culminus"})



	sets.midcast.SkillBasedEnfeebling = set_combine(sets.midcast['Enfeebling Magic'], {ear1="Vor Earring",hands="Leth. Gantherots +1",ring1="Stikini Ring +1",legs="Psycloth Lappas"})
	
    sets.midcast['Frazzle II']            = sets.midcast['Enfeebling Magic'].Resistant
    sets.midcast['Frazzle III']           = sets.midcast.SkillBasedEnfeebling
    sets.midcast['Frazzle III'].Resistant = sets.midcast['Enfeebling Magic'].Resistant
    sets.midcast['Distract III']          = sets.midcast.SkillBasedEnfeebling
    sets.midcast['Distract III'].Resistant = sets.midcast['Enfeebling Magic'].Resistant

	-- =========================================================================
	-- [FIX 4]: sets.midcast['Elemental Magic'] moved UP here, above Divine Magic,
	--          MagicBurst, and Dark Magic — all three of which reference it via
	--          set_combine. In the original file it was defined ~40 lines further
	--          down, so those three set_combine calls were passing nil as their
	--          base table, which throws and halts the entire file from loading.
	-- =========================================================================
    sets.midcast['Elemental Magic'] = {
        main  ="Marin Staff +1",
        sub   ="Willpower Grip",
        ammo  ="Ghastly Tathlum",
        head  ="Lethargy Chappel +2",
        body  ="Bunzi's Robe",
        legs  ="Lethargy Fuseau +3",
        hands ="Lethary Gantherots +2",
        feet  ="Lethargy Houseaux +3",
        neck  ="Baetyl Pendant",
        ear1  ="Malignance Earring",
        ear2  ="Hecate's Earring",
        ring2 ="Jhakri Ring",
        ring1 ="Resonance Ring",
        back  ="Izdubar Mantle",
        waist ="Hachirin-no-obi"
    }
		
	sets.midcast['Elemental Magic'].Resistant = set_combine(sets.midcast['Elemental Magic'], {
		main = "Mpaca's Staff",
		neck = "Incanter's Torque",
		head = "Atrophy Chapeau +2",
		waist = "Null Belt",
		back = "Null Shawl",
        ranged="Kaja Bow"
	})
		
    sets.midcast['Elemental Magic'].Fodder = set_combine(sets.midcast['Elemental Magic'], {})
    sets.midcast['Elemental Magic'].Proc   = set_combine(sets.midcast['Elemental Magic'], {
    })

    sets.midcast['Elemental Magic'].HighTierNuke           = set_combine(sets.midcast['Elemental Magic'], {})
    sets.midcast['Elemental Magic'].HighTierNuke.Resistant = set_combine(sets.midcast['Elemental Magic'].Resistant, {})
    sets.midcast['Elemental Magic'].HighTierNuke.Fodder    = set_combine(sets.midcast['Elemental Magic'].Fodder, {})

    sets.midcast.Impact = set_combine(sets.midcast['Elemental Magic'], {head=empty, body="Twilight Cloak"})

	-- Gear for Magic Burst mode. (combines against the now fully-defined Elemental Magic set)
    sets.MagicBurst = set_combine(sets.midcast['Elemental Magic'], {
        main="Bhunzi's Rod", 
        sub="Culminus",
        head="Bunzi's Hat",
        body="Bunzi's Robe",
        hands="Bunzi's Gloves",
        legs="Lethargy Fuseau +3",
        feet="Bunzi's Sabots",
        neck  ="Mizukage-no-Kubikazari",
        ring2 ="Mujin Band",
        ring1 ="Locus Ring",

    })

	-- [FIX 4 cont.]: Divine Magic now resolves correctly, since Elemental Magic exists above it.
	sets.midcast['Divine Magic'] = set_combine(sets.midcast['Elemental Magic'], {
        feet="Medium's Sabots",
        body="Vanya Robe",
    })

	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast.Diaga = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Dia II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Dia III'] = set_combine(sets.midcast['Enfeebling Magic'], {waist="Chaac Belt"})
	
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Bio II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Bio III'] = set_combine(sets.midcast['Enfeebling Magic'], {head="Viti. Chapeau +3",waist="Chaac Belt",feet=gear.chironic_treasure_feet})

	 sets.midcast['Dark Magic'] = {
        head  ="Jhakri Coronal +2",
        body  ="Jhakri Robe +2",
        legs  ="Jhakri Slops +2",
        hands ="Malignance Gloves",
        feet  ="Jhakri Pigaches +2",
        neck  ="Erra Pendant",
        ear2  ="Abyssal Earring",
        ear1  ="Malignance Earring",
        ring1 ="Crepuscular Ring",
        ring2="Evanescence Ring",
        back  ="Izdubar Mantle",
        waist =gear.default.waist
    }

    sets.midcast.Drain          = set_combine(sets.midcast['Dark Magic'], {neck="Erra Pendant"})
    sets.midcast.Aspir          = set_combine(sets.midcast.Drain, {waist="Fucho-no-obi", feet="Merlinic Crackows"})
    sets.midcast.Stun           = set_combine(sets.midcast['Dark Magic'], {})
    sets.midcast.Stun.Resistant = set_combine(sets.midcast['Dark Magic'], {})


	-- Sets for special buff conditions on spells.
		
  sets.buff.Saboteur      = {hands="Lethargy Gantherots +2"}
    sets.buff.Sublimation   = {waist="Embla Sash"}
    sets.buff.DTSublimation = {waist="Embla Sash"}
    sets.HPDown             = {}
    sets.HPCure             = {}
    sets.buff.Doom          = {}
	-- Sets to return to when not performing an action.
	
	-- Resting sets
	sets.resting = {main="Chatoyant Staff",sub="Oneiros Grip",}
	

	-- Idle sets
	sets.idle = { 
        main="Mpaca's Staff",
        sub="Umbra Strap",
        ammo  ="Crepuscular Pebble",
        head  ="Vitiation Chapeau +3",
        body  ="Lethargy Sayon +3",
        legs  ="Carmine Cuisses +1",
        hands ="Malignance Gloves",
        feet  ="Battlecast Gaiters",
        neck  ="Null Loop",
        ear1  ="Moonshade Earring",
        ear2  ="Alabaster Earring",
        ring1="Ayanmo Ring",
        ring2 ="Murky Ring",
        back  ="Archon Cape",
        waist ="Null Belt"}
		
	sets.idle.PDT     = set_combine(sets.idle, 
	{main="Chatoyant Staff",
        sub="Umbra Strap",})
    sets.idle.MDT     = set_combine(sets.idle, {})
    sets.idle.Weak    = set_combine(sets.idle, {})
    sets.idle.DTHippo = set_combine(sets.idle, {})
	
	sets.idle.DTHippo = set_combine(sets.idle.PDT, {
	back="Umbra Cape",
	legs="Carmine Cuisses +1",
	--feet="Hippo. Socks +1"
	})
	
	-- Defense sets
	sets.defense.PDT = {}

	sets.defense.NukeLock = sets.midcast['Elemental Magic']
		
	sets.defense.MDT =  set_combine(sets.idle.MDT,{})
		
    sets.defense.MEVA = set_combine(sets.defense.MDT,{})
		
	sets.Kiting = {legs="Carmine Cuisses +1"}
	sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.latent_refresh_grip = {main= "Mpaca's Staff", sub="Oneiros Grip"}
	sets.TPEat = {neck="Chrys. Torque"}
	sets.DayIdle = {}
	sets.NightIdle = {}
	
	-- Weapons sets
	sets.weapons.Naegling = {main="Naegling",sub="Archduke's Shield"} -- Default (non-NIN sub) Naegling loadout
	sets.weapons.DualWeapons = {main="Naegling", sub="Demersal Degen +1", range="Kaja Bow", ammo=empty } -- [FIX] No longer a manual cycle stop; used automatically when sub job is NIN — see job_handle_equipping_gear()
	sets.weapons.EnspellMelee = {main="Naegling", sub="Culminus",} -- Non-NIN-sub melee: rides enspell procs via Culminus instead of using a shield
	sets.weapons.DualBow = {main="Naegling",sub="Demersal Degen +1",range="Kaja Bow"}
	sets.weapons.BowMacc = {range="Kaja Bow",ammo=empty}
    sets.buff.Sublimation = {waist="Embla Sash"}
    sets.buff.DTSublimation = {waist="Embla Sash"}

	-- Engaged sets

	-- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
	-- sets if more refined versions aren't defined.
	-- If you create a set with both offense and defense modes, the offense mode should be first.
	-- EG: sets.Dagger.Accuracy.Evasion
	
	-- Normal melee group
--	sets.engaged = {ammo="Aurgelmir Orb +1",
--		head="Aya. Zucchetto +2",neck="Asperity Necklace",ear1="Cessance Earring",ear2="Cessance Earring",
--		body="Ayanmo Corazza +2",hands="Aya. Manopolas +2",ring1="Petrov Ring",ring2="Ilabrat Ring",
--		back=gear.stp_jse_back,waist="Windbuffet Belt +1",legs="Carmine Cuisses +1",feet="Carmine Greaves +1"}

sets.engaged = {  neck  ="Null Loop",
        ear1  ="Sherida Earring",
        ear2  ="Cessance Earring",
        body  ="Malignance Tabard",
        hands ="Malignance Gloves",
        ring1 ="Mars's Ring",
        ring2 ="Rajas Ring",
        back  ="Null Cape",
        waist ="Sailfi Belt",
        legs  ="Malignance Tights",
        feet  ="Ayanmo Gambieras +2",
        ammo  ="Ginsen"}

sets.engaged.EnspellMelee = sets.engaged

sets.engaged.Acc = set_combine(sets.engaged, {ranged="Kaja Bow"})
sets.engaged.FullAcc = set_combine(sets.engaged.Acc, {})
sets.engaged.DT = set_combine(sets.engaged, {})

sets.engaged.Acc.DT = set_combine(sets.engaged.Acc, {})
sets.engaged.FullAcc.DT = set_combine(sets.engaged.FullAcc, {})

sets.engaged.DW = set_combine(sets.engaged, {})
sets.engaged.DW.Acc = set_combine(sets.engaged.Acc, {})
sets.engaged.DW.FullAcc = set_combine(sets.engaged.FullAcc, {})
sets.engaged.DW.DT = set_combine(sets.engaged, {})

sets.engaged.DW.Acc.DT = set_combine(sets.engaged.Acc, {})
sets.engaged.DW.FullAcc.DT = set_combine(sets.engaged.FullAcc, {})
end



-- [FIX] Auto-swap Naegling's off-hand/range depending on current sub job.
-- Safety net: runs on normal equip events (engaging, casting, etc). Only touches gear
-- when state.Weapons is on 'Naegling':
--   Sub job NIN     -> Demersal Degen +1 + Kaja Bow (dual wield / ranged accuracy)
--   Any other sub   -> Archduke's Shield (defensive default)
function job_handle_equipping_gear(playerStatus, eventArgs)
    if state.Weapons.value == 'Naegling' then
        if player.sub_job == 'NIN' then
            equip(sets.weapons.DualWeapons)
        else
            equip(sets.weapons.Naegling)
        end
    end
end

-- [FIX2] Primary trigger for Ctrl+W. Cycles state.Weapons, then immediately equips the
-- correct set for the NEW mode right here — no dependency on job_handle_equipping_gear
-- firing afterward, which is what was causing the shield to stick around incorrectly.
function job_self_command(cmdParams, eventArgs)
    if cmdParams[1] == 'weaponcycle' then
        state.Weapons:cycle()
        if state.Weapons.value == 'Naegling' then
            if player.sub_job == 'NIN' then
                equip(sets.weapons.DualWeapons)
            else
                equip(sets.weapons.Naegling)
            end
        elseif state.Weapons.value == 'EnspellMelee' then
            equip(sets.weapons.EnspellMelee)
        end
        eventArgs.handled = true
    end
end

function select_default_macro_book()
    set_macro_page(1, 3)
end

function user_job_lockstyle()
    send_command('input /lockstyleset 3')
end