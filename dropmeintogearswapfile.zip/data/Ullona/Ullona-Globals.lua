
latency = .67

--If this is set to true it will prevent you from casting shadows when you have more up than that spell would generate.
conserveshadows = false

--Display related settings.
state.DisplayMode = M(true, 'Display Mode') --Set this to false if you don't want to display modes at the bottom of your screen.
--Uncomment the settings below and change the values to edit the display's look.
--displayx = 3
--displayy = 1062
--displayfont = 'Arial'
--displaysize = 12
--displaybold = true
--displaybg = 0
--displaystroke = 2
--displaytransparancy = 192
--state.DisplayColors = {
    -- h='\\cs(255, 0, 0)', -- Red for active booleans and non-default modals
    -- w='\\cs(255,255,255)', -- White for labels and default modals
    -- n='\\cs(192,192,192)', -- White for labels and default modals
    -- s='\\cs(96,96,96)' -- Gray for inactive booleans
--}

--Options for automation.
state.ReEquip 		  		= M(true, 'ReEquip Mode')		 --Set this to false if you don't want to equip your current Weapon set when you aren't wearing any weapons.
state.AutoArts 		  		= M(true, 'AutoArts') 		 --Set this to false if you don't want to automatically try to keep up Solace/Arts.

-- [FIX] Shared ElementalMode wheel order, applied to every job automatically. Overrides
-- Sel-Include.lua's default order (Fire/Ice/Wind/Earth/Lightning/Water/Light/Dark) -- this
-- file loads after Sel-Include sets that default but before individual job_setup() calls, so
-- any job's own state.ElementalMode override (if it ever defines one, like WHM currently does)
-- still wins for that specific job. Everything else falls through to this consistent order.
state.ElementalMode = M{['description'] = 'Elemental Mode','Lightning','Ice','Fire','Wind','Water','Earth','Dark','Light',}

-- [FIX] Silences ALL chat announcements tied to cycling ElementalMode -- both the built-in
-- "DisplayElement" self-command (a side effect of state_change, silenced below) AND the
-- generic "Elemental Mode is now Fire." line that Sel-SelfCommands.lua's handle_cycle prints
-- directly (add_to_chat(122,descrip..' is now '..state_var.current..'.'), confirmed by reading
-- that file -- Sel-Modes.lua's M class itself prints nothing at all). Can't edit either
-- framework file (reference-only), so 'cycle ElementalMode'/'cycleback ElementalMode' are
-- intercepted here and handled manually -- replicating handle_cycle's real behavior (cycle the
-- value, fire state_change, refresh gear via handle_update) with the chat line left out. Every
-- OTHER state's cycle command (OffenseMode, IdleMode, CastingMode, etc.) is left completely
-- untouched and still announces normally -- this only ever fires for ElementalMode specifically.
function user_self_command(cmdParams, eventArgs)
    if cmdParams[1]:lower() == 'displayelement' then
        eventArgs.handled = true
        return
    end

    if cmdParams[2] and cmdParams[2]:lower() == 'elementalmode' and (cmdParams[1]:lower() == 'cycle' or cmdParams[1]:lower() == 'cycleback') then
        local oldVal = state.ElementalMode.value
        if cmdParams[1]:lower() == 'cycleback' then
            state.ElementalMode:cycleback()
        else
            state.ElementalMode:cycle()
        end
        local newVal = state.ElementalMode.value

        if state_change then
            state_change(state.ElementalMode.description, newVal, oldVal)
        end

        handle_update({'auto'})
        eventArgs.handled = true
        return
    end

    if cmdParams[1]:lower() == 'cycledefensesub' then
        -- Cycles state.PhysicalDefenseMode / state.MagicalDefenseMode / state.ResistDefenseMode
        -- -- whichever one matches the currently active state.DefenseMode flavor -- using the
        -- same dynamic-name pattern Sel-Include.lua itself uses internally
        -- (state[state.DefenseMode.current..'DefenseMode']) to pick the right one. Consolidates
        -- what used to be three separate keys (one per flavor) into a single context-aware bind.
        if state.DefenseMode.value == 'None' then
            add_to_chat(123,'No defense mode active -- nothing to cycle.')
        else
            local subState = state[state.DefenseMode.value..'DefenseMode']
            if subState then
                subState:cycle()
                if state.DisplayMode.value then update_job_states() end
            end
        end
        eventArgs.handled = true
        return
    end

    if cmdParams[1]:lower() == 'utsusemi' then
        handle_utsusemi(cmdParams)
        eventArgs.handled = true
        return
    end

    if cmdParams[1]:lower() == 'smartwaltz' then
        handle_smartwaltz(cmdParams)
        eventArgs.handled = true
    end
end

-- Utsusemi tier-down: San (5 shadows, fastest) -> Ni (3-4 shadows) -> Ichi (3 shadows, slowest
-- cast). Tries the strongest tier first, stepping down only if it's on cooldown or you don't
-- have access to it (silent_can_use handles the latter gracefully -- e.g. San requires higher
-- Ninjutsu access than sub-job NIN may have). Shared across every job here since RDM, THF, and
-- WHM's gear files all define sets.midcast.Utsusemi already -- this isn't job-specific.
function handle_utsusemi(cmdParams)
    local spell_recasts = windower.ffxi.get_spell_recasts()
    local tiers = {'Utsusemi: San', 'Utsusemi: Ni', 'Utsusemi: Ichi'}
    for k in ipairs(tiers) do
        local spell = get_spell_table_by_name(tiers[k])
        if spell and silent_can_use(spell.id) and spell_recasts[spell.id] < spell_latency then
            windower.chat.input('/ma "'..tiers[k]..'" <me>')
            return
        end
    end
    add_to_chat(123,'Abort: All Utsusemi tiers on cooldown or unavailable.')
end

-- Looks up a job ability's recast index by name against Windower's standard res.job_abilities
-- resource table, rather than hardcoding a guessed numeric ID -- stays correct even if a
-- wrong ID would've silently pointed at some other ability's cooldown instead. Returns nil if
-- no ability by that name is found (e.g. it's not unlocked, or the name doesn't exist).
-- [MOVED 2026-07-26]: used to live only in THF.lua (for Assassin's Charge); relocated here
-- since handle_smartwaltz() below needs the same lookup and isn't THF-specific.
function get_ability_recast_id_by_name(name)
	for id, ability in pairs(res.job_abilities) do
		if ability.en == name then
			return ability.recast_id
		end
	end
	return nil
end

-- Haste-tier melee gear grouping: NEW 2026-07-26, ported from a friend's THF file and made
-- global here since more than one job benefits from it. Checks which haste sources are
-- currently stacked and tags classes.CustomMeleeGroups with 'Haste_15', 'Haste_30', or
-- 'MaxHaste' so engaged gear can hit different Accuracy/Store TP priorities depending on how
-- much haste you're actually sitting at, rather than one set trying to cover both 15% and
-- 40%+ haste equally badly.
--
-- [CONFIRMED SAFE 2026-07-26]: get_melee_set() in Sel-Include.lua only layers in a
-- CustomMeleeGroups tag if sets.engaged[tag] actually exists for whatever job is currently
-- active -- if a job's gear file hasn't defined sets.engaged.Haste_15/Haste_30/MaxHaste yet,
-- the tag is silently skipped, no error. So this is safe to run globally even before every
-- job's gear file has real gear for these tiers -- it just has no visible effect until then.
--
-- Rough percentages (not exact, just for context): Haste (white magic) ~15%, Haste Samba
-- (DNC sub) ~5%, Geo-Haste ~15-21%, March ~4-5% per stack (2 stacks from a quality Bard sub),
-- Embrava ~30% (with high Enhancing skill), Mighty Guard ~15%.
function determine_haste_group()
	classes.CustomMeleeGroups:clear()

	if (buffactive['Haste'] and (buffactive['March'] or buffactive['Mighty Guard'])) or
		(buffactive['Haste'] and (buffactive['Geo-Haste'] or buffactive['Embrava'])) or
		(buffactive['March'] == 2 and buffactive['Mighty Guard']) then
		classes.CustomMeleeGroups:append('MaxHaste')
	elseif buffactive['Geo-Haste'] or buffactive['Haste'] or buffactive['March'] == 2 or
		(buffactive['March'] == 1 and buffactive['Mighty Guard']) then
		classes.CustomMeleeGroups:append('Haste_30')
	elseif buffactive['March'] == 1 or buffactive['Mighty Guard'] or buffactive['Haste Samba'] then
		classes.CustomMeleeGroups:append('Haste_15')
	end
end

local haste_related_buffs = S{'haste', 'march', 'mighty guard', 'embrava', 'haste samba', 'geo-haste', 'indi-haste'}

-- Global buff-change hook (Sel-Include.lua checks for this automatically on every job, same
-- pattern as user_tick/user_self_command -- no per-job wiring needed). Re-evaluates the
-- haste-tier group whenever a haste-related buff lands or drops, and re-equips immediately
-- unless a spell/ability is actively resolving.
function user_buff_change(buff, gain, eventArgs)
	if haste_related_buffs:contains(buff:lower()) then
		determine_haste_group()
		if not midaction() then
			handle_equipping_gear(player.status)
		end
	end
end

-- Smart Waltz: NEW 2026-07-26. Same missingHP-estimate targeting pattern as every job's
-- handle_smartcure() (see RDM/WHM/BLM/GEO/SCH/SMN), but built around Curing Waltz I-V -- a
-- job ability, not a spell -- for whenever you're subbing /DNC on a job that isn't DNC
-- itself (hence living here in Globals rather than in any one job file: "sometimes you gotta
-- dance not on THF"). Checked DNC.lua itself first -- it has no equivalent logic of its own
-- to conflict with or duplicate.
--
-- Uses TP cost (verified against the wiki, 2026-07-26) + ability recast (via
-- get_ability_recast_id_by_name above) instead of MP + spell recast, since Waltzes draw from
-- TP. [ASSUMPTION]: the missingHP breakpoints below are still rough estimates, not measured
-- Waltz potency numbers -- tune them if they don't feel right in practice. Waltzes can't
-- target monsters or raise the dead, so those get an abort message instead of the
-- Cure-equivalent Arise/monster-cure branches.
local waltz_tp_cost = {
	['Curing Waltz'] = 200,
	['Curing Waltz II'] = 350,
	['Curing Waltz III'] = 500,
	['Curing Waltz IV'] = 650,
	['Curing Waltz V'] = 800,
}

-- Ordered cheapest -> priciest. Used both for the strict tier-down cascade and for picking
-- the "desired" tier by severity.
local waltz_tiers_asc = {'Curing Waltz', 'Curing Waltz II', 'Curing Waltz III', 'Curing Waltz IV', 'Curing Waltz V'}

local function waltz_ready(tierName)
	local id = get_ability_recast_id_by_name(tierName)
	if not id then return false end
	local abil_recasts = windower.ffxi.get_ability_recasts()
	return abil_recasts[id] and abil_recasts[id] < latency and player.tp >= (waltz_tp_cost[tierName] or 0)
end

local function cast_waltz(tierName, targetId)
	windower.chat.input('/ja "'..tierName..'" '..targetId..'')
end

function handle_smartwaltz(cmdParams)
	if player.sub_job ~= 'DNC' then
		add_to_chat(123,'Abort: Smart Waltz requires /DNC subjob.')
		return
	end

	-- [CHANGED 2026-07-26]: no-argument behavior now checks your OWN hp first, since <st>
	-- click-prompting every single time got clunky fast. Below 75% HP, just dance on
	-- yourself directly -- skips the click, and gets the full missingHP-based tier
	-- selection since your own HP is obviously already known. Above 75%, falls back to the
	-- <st> click prompt (click self or an ally) with best-available tier, same as before --
	-- your target is almost always the monster you're fighting while meleeing, so there's
	-- still no sensible default to assume for someone ELSE without asking.
	--
	-- Pass a party member's name or ID explicitly (e.g. `gs c smartwaltz Ulli`) to skip the
	-- click prompt entirely and get the full missingHP-based tier selection for them instead.
	if not cmdParams[2] and player.hpp >= 75 then
		for i = #waltz_tiers_asc, 1, -1 do
			if waltz_ready(waltz_tiers_asc[i]) then
				cast_waltz(waltz_tiers_asc[i], '<st>')
				return
			end
		end
		add_to_chat(123,'Abort: No Curing Waltz available (recast/TP/unlocked).')
		return
	end

	local cureTarget
	if not cmdParams[2] then
		-- Got here via the low-HP self-heal short-circuit above -- always self.
		cureTarget = player
	elseif tonumber(cmdParams[2]) then
		cureTarget = windower.ffxi.get_mob_by_id(tonumber(cmdParams[2]))
	else
		local targetName = table.concat(cmdParams, ' ', 2)
		cureTarget = get_closest_mob_by_name(targetName)
	end
	if not cureTarget or not cureTarget.name then cureTarget = player end

	if cureTarget.type == 'MONSTER' then
		add_to_chat(123,'Abort: Waltzes cannot target monsters.')
		return
	end

	if cureTarget.status == 2 or cureTarget.status == 3 then
		add_to_chat(123,'Abort: Target is down -- Waltzes cannot raise.')
		return
	end

	local missingHP
	if cureTarget.in_alliance then
		cureTarget.hp = find_player_in_alliance(cureTarget.name).hp
		local est_max_hp = cureTarget.hp / (cureTarget.hpp/100)
		missingHP = math.floor(est_max_hp - cureTarget.hp)
	else
		local est_current_hp = 1800 * (cureTarget.hpp/100)
		missingHP = math.floor(1800 - est_current_hp)
	end

	local tid = cureTarget.id

	-- Desired tier by severity -- same breakpoints as before, just picking a single named
	-- tier now instead of a hand-rolled fallback list per band.
	local desiredTier
	if missingHP < 200 then desiredTier = 'Curing Waltz'
	elseif missingHP < 500 then desiredTier = 'Curing Waltz II'
	elseif missingHP < 850 then desiredTier = 'Curing Waltz III'
	elseif missingHP < 1300 then desiredTier = 'Curing Waltz IV'
	else desiredTier = 'Curing Waltz V' end

	-- If the desired tier isn't affordable right now but a Flourish buff is up, spend Reverse
	-- Flourish to convert it into TP first, then re-run this same command a moment later --
	-- better to burn a second regenerating TP than either undercure unnecessarily or waste a
	-- bigger heal we can't actually afford yet. Only does this when TP is the actual blocker
	-- (not e.g. every tier being on cooldown), and only if Reverse Flourish itself is ready.
	if player.tp < (waltz_tp_cost[desiredTier] or 0) and (state.Buff['Climactic Flourish'] or state.Buff['Building Flourish']) then
		local rf_id = get_ability_recast_id_by_name('Reverse Flourish')
		local abil_recasts = windower.ffxi.get_ability_recasts()
		if rf_id and abil_recasts[rf_id] and abil_recasts[rf_id] < latency then
			windower.chat.input('/ja "Reverse Flourish" <me>')
			local retryArgs = 'smartwaltz'
			if cmdParams[2] then retryArgs = retryArgs..' '..table.concat(cmdParams, ' ', 2) end
			windower.chat.input:schedule(1.5, 'gs c '..retryArgs)
			return
		end
	end

	-- Tier DOWN only, from the desired tier to the cheapest -- never up. TP cost only climbs
	-- at higher tiers, so if the desired tier isn't ready (cooldown or TP), a pricier tier
	-- definitely won't be either. Rather undercure than not cure at all.
	local startIdx
	for i, t in ipairs(waltz_tiers_asc) do
		if t == desiredTier then startIdx = i break end
	end

	for i = startIdx, 1, -1 do
		if waltz_ready(waltz_tiers_asc[i]) then
			cast_waltz(waltz_tiers_asc[i], tid)
			return
		end
	end

	add_to_chat(123,'Abort: No Curing Waltz available (recast/TP/unlocked).')
end

-- [YEETED 2026-07-26]: Auto-Defense (HP) removed entirely at request -- caused more headaches
-- than it solved in practice. Used to live here as user_tick(), auto-swapping into Physical
-- DefenseMode below 70% HP while Engaged. If a Sel-Include.lua-driven auto-behavior like this
-- gets revisited later, this is the spot for it -- Sel-Include.lua's tick loop already checks
-- `if user_tick then user_tick() then return end`, so simply not having this function defined
-- is safe; nothing else here depends on it existing.

-- Simple fixed threshold -- 75% MP, no per-job modal to remember to toggle.
function should_recover_mp()
    return player.mpp < 75
end

-- Auto-Recover MP: shared across every mage job. Equips sets.RecoverMP (or its Magic Burst
-- variant, when applicable) any time MP drops below 75%. Call this from a job's
-- job_post_midcast(), after any Magic Burst gear has already been layered on, so this has
-- final say over the MP-recovery slots:
--     try_recover_mp()
--
-- Preserves the original RecoverBurst/ResistantRecoverBurst selection logic that used to
-- live independently inside BLM.lua and RDM.lua -- if Magic Burst Mode is active, prefers
-- ResistantRecoverBurst (under a Resistant casting mode) or RecoverBurst over the plain
-- RecoverMP set, falling back gracefully if a job hasn't defined those extra sets.
--
-- state.Buff['Manafont']/['Manawell'] are BLM-only buffs -- indexing them on a job that never
-- tracks those keys just returns nil/false, so this is safe to call unconditionally from any
-- mage job without special-casing BLM.
--
-- SMN only recovers MP while no avatar is summoned -- Blood Pact economy and the avatar's own
-- gear priorities take precedence the instant one is out.
local mage_jobs = S{'WHM','RDM','BLM','GEO','SCH','SMN'}

function try_recover_mp()
    if not mage_jobs:contains(player.main_job) then return end
    if player.main_job == 'SMN' and pet.isvalid then return end
    if not should_recover_mp() then return end
    if state.Buff['Manafont'] or state.Buff['Manawell'] then return end
    if not sets.RecoverMP then return end

    if state.MagicBurstMode and state.MagicBurstMode.value ~= 'Off' then
        if state.CastingMode.value:contains('Resistant') and sets.ResistantRecoverBurst then
            equip(sets.ResistantRecoverBurst)
        elseif sets.RecoverBurst then
            equip(sets.RecoverBurst)
        else
            equip(sets.RecoverMP)
        end
    else
        equip(sets.RecoverMP)
    end
end

-- =============================================================================
-- Shared cure/weather helper — for any job subbing SCH (RDM, WHM currently;
-- SCH/GEO/BRD/BLM later). Call this from a job's handle_smartcure() right after
-- missingHP AND cureTarget are known, BEFORE the actual cure spell fires:
--     check_aurorastorm_for_cure(missingHP, cureTarget)
-- Behavior when Aurorastorm isn't already up:
--   Self-preservation override: if cureTarget IS the player and player.hpp < 75,
--       ALWAYS skip weather regardless of missingHP — don't die because of Aurorastorm.
--   missingHP < 400  (routine top-off, tier I-III territory) -> queues Aurorastorm,
--       the cure naturally casts right behind it once weather finishes.
--   missingHP >= 400 (bigger gap, emergency-tier cure incoming) -> skips weather
--       entirely, just echoes a reminder. More important things going on than weather.
-- Does nothing at all if not currently subbing SCH, or if Aurorastorm's already up.
--
-- [RESTORED] This lived in user-globals.lua originally. That file got intentionally
-- blanked to just "--I EXIST." (GearSwap's optional_include still requires the file
-- to exist even though it's "optional"), which silently deleted this function along
-- with everything else in it. Nothing carried it over to this file at the time, so
-- every call site (WHM.lua's handle_smartcure/handle_smartcuraga/handle_smartcura)
-- started throwing "attempt to call global 'check_aurorastorm_for_cure' (a nil
-- value)". This is now the sole copy — Ullona-Globals.lua is the single source of
-- truth per the earlier consolidation, so this must never be duplicated back into
-- user-globals.lua.
-- =============================================================================
function check_aurorastorm_for_cure(missingHP, cureTarget)
    if not missingHP then return end
    if player.sub_job ~= 'SCH' then return end
    if buffactive['Aurorastorm'] then return end

    -- Self-preservation override: healing yourself while under 75% HP always skips
    -- weather, no matter how small the missing HP looks. Not dying > refreshing weather.
    if cureTarget == player and player.hpp < 75 then
        add_to_chat(167, 'Aurorastorm is down, but self-preservation comes first.')
        return
    end

    if missingHP < 400 then
        windower.chat.input('/ma "Aurorastorm" <me>')
    else
        add_to_chat(167, 'Aurorastorm is down, but this cure comes first.')
    end
end
state.AutoLockstyle	 	    = M(true, 'AutoLockstyle Mode') --Set this to false if you don't want gearswap to automatically lockstyle on load and weapon change.
state.CancelStoneskin 		= M(true, 'Cancel Stone Skin') --Set this to false if you don't want to automatically cancel stoneskin when you're slept.
state.SkipProcWeapons 		= M(true, 'Skip Proc Weapons') --Set this to false if you want to display weapon sets fulltime rather than just Aby/Voidwatch.
state.NotifyBuffs	  		= M(false, 'Notify Buffs') 	 --Set this to true if you want to notify your party when you recieve a specific buff/debuff. (List Below)

--[[Binds you may want to change.
	Bind special characters.
	@ = Windows Key
	% = Works only when text bar not up.
	$ = Works only when text bar is up.
	^ = Control Key
	! = Alt Key
	~ = Shift Key
	# = Apps Key
]]

send_command('bind ^` gs c cycle ElementalMode') --Ctrl+`             : Cycle ElementalMode forward (Lightning/Ice/Fire/Wind/Water/Earth/Dark/Light)
send_command('bind ~^` gs c cycleback ElementalMode') --Shift+Ctrl+`  : Cycle ElementalMode backward+`  : Cycle ElementalMode backward
send_command('bind !` gs c cycle MagicBurstMode') --Alt+`             : Cycle MagicBurstMode (Off/Single/etc.)
send_command('bind !@^f7 gs c toggle AutoWSMode') --Alt+Win+Ctrl+F7 : Turns auto-ws mode on and off.
send_command('bind !^f7 gs c toggle AutoFoodMode') --Alt+Ctrl+F7     : Turns auto-food mode on and off.
send_command('bind ^f7 gs c cycle Weapons') --Ctrl+F7               : Cycle through weapons sets.
send_command('bind @f8 gs c toggle AutoNukeMode') --Win+F8          : Turns auto-nuke mode on and off.
send_command('bind ^f8 gs c toggle AutoStunMode') --Ctrl+F8         : Turns auto-stun mode off and on.
send_command('bind !f8 gs c toggle AutoDefenseMode') --Alt+F8       : Turns auto-defense mode off and on.
send_command('bind ^@!f8 gs c toggle AutoTrustMode') --Ctrl+Win+Alt+F8 : Summons trusts automatically.
send_command('bind @pause gs c cycle AutoBuffMode') --Win+Pause     : Automatically keeps certain buffs up, job-dependant.
send_command('bind @scrolllock gs c cycle Passive') --Win+Scroll Lock : Changes offense settings such as accuracy.
send_command('bind ^!f9 gs c cycle OffenseMode') --Ctrl+Alt+F9      : Changes offense settings such as accuracy.
send_command('bind ^f9 gs c cycle HybridMode') --Ctrl+F9            : Changes defense settings for melee such as PDT.
send_command('bind @f9 gs c cycle RangedMode') --Win+F9             : Changes ranged offense settings such as accuracy.
send_command('bind !f9 gs c cycle WeaponskillMode') --Alt+F9        : Allows automatic weaponskilling if the job is setup to handle it.
send_command('bind ^!f10 gs c cycle DefenseMode') --Ctrl+Alt+F10    : Cycle Defense Mode (None -> Physical -> Magical -> Resist -> loop)
send_command('bind ^f10 gs c cycledefensesub') --Ctrl+F10            : Cycle the sub-variant of whichever defense mode is currently active (does nothing if DefenseMode is None)
send_command('bind !f10 gs c toggle Kiting') --Alt+F10              : Keeps your kiting gear on..
send_command('bind @f11 gs c cycle CastingMode') --Win+F11          : Changes your castingmode options such as magic accuracy.
send_command('bind !f11 gs c cycle ExtraMeleeMode') --Alt+F11       : Adds another set layered on top of your engaged set.
send_command('bind @f12 gs c cycle IdleMode') --Win+F12             : Changes your idle mode options such as refresh.
send_command('bind ^@!f12 gs reload') --Ctrl+Win+Alt+F12            : Reloads gearswap.
send_command('bind pause gs c update user') --Pause                 : Runs a quick check to make sure you have the right gear on and checks variables.
send_command('bind ^@!pause gs org') --Ctrl+Win+Alt+Pause           : Runs organizer.
send_command('bind ^@!backspace gs c buffup') --Ctrl+Win+Alt+Backspace : Buffup macro because buffs are love.
send_command('bind ^r gs c weapons Default') --Ctrl+R               : Requips weapons and gear.
send_command('bind ^z gs c toggle Capacity') --Ctrl+Z               : Keeps capacity mantle on and uses capacity rings.
send_command('bind ^y gs c toggle AutoCleanupMode') --Ctrl+Y        : Uses certain items and tries to clean up inventory.
send_command('bind ^t gs c cycle treasuremode') --Ctrl+T            : Toggles hitting htings with your treasure hunter set.
send_command('bind !t input /target <bt>') --Alt+T                  : Targets the battle target.
send_command('bind ^o fillmode') --Ctrl+O                           : Lets you see through walls.

NotifyBuffs = S{'doom','petrification'}

bayld_items = {'Tlalpoloani','Macoquetza','Camatlatia','Icoyoca','Tlamini','Suijingiri Kanemitsu',
'Zoquittihuitz','Quauhpilli Helm','Chocaliztli Mask','Xux Hat','Quauhpilli Gloves','Xux Trousers',
'Chocaliztli Boots','Maochinoli','Xiutleato','Hatxiik','Kuakuakait','Azukinagamitsu','Atetepeyorg',
'Kaquljaan','Ajjub Bow','Baqil Staff','Ixtab','Tamaxchi','Otomi Helm','Otomi Gloves','Kaabnax Hat',
'Kaabnax Trousers','Ejekamal Mask','Ejekamal Boots','Quiahuiz Helm','Quiahuiz Trousers','Uk\'uxkaj Cap'}

--[[ List of all Bayld Items.
bayld_items = {'Tlalpoloani','Macoquetza','Camatlatia','Icoyoca','Tlamini','Suijingiri Kanemitsu','Zoquittihuitz',
'Quauhpilli Helm','Chocaliztli Mask','Xux Hat','Quauhpilli Gloves','Xux Trousers','Chocaliztli Boots','Maochinoli',
'Hatxiik','Kuakuakait','Azukinagamitsu','Atetepeyorg','Kaquljaan','Ajjub Bow','Baqil Staff','Ixtab','Otomi Helm',
'Otomi Gloves','Kaabnax Hat','Kaabnax Trousers','Ejekamal Mask','Ejekamal Boots','Quiahuiz Helm','Quiahuiz Trousers',
'Uk\'uxkaj Cap'}
]]