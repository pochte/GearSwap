-- =============================================================================
-- Ullona_Rdm_Gear.lua — Changelog
-- 2026-07-15: Added sets.element and sets.element.enspell stub tables (blank per element:
--             Fire/Ice/Wind/Earth/Lightning/Water/Light/Dark). Neither existed before, which
--             meant RDM.lua's job_post_midcast (nuke bonus gear) and job_customize_melee_set
--             (enspelled melee bonus gear) were both indexing a nil sets.element and crashing
--             -- on every nuke AND every enspelled swing under EnspellMelee. Populate the
--             element sub-tables with real gear whenever you're ready.
-- 2026-07-15: Fixed a "ranged=" -> "range=" typo in four places (sets.midcast['Enfeebling
--             Magic'], its .Resistant variant, and sets.engaged.Acc). "ranged" isn't a
--             recognized GearSwap slot key and was being silently ignored, meaning Kaja Bow
--             was never actually equipping for Magic Accuracy on those sets at all.
-- 2026-07-15: Added range="Kaja Bow", ammo=empty directly to sets.weapons.EnspellMelee -- it
--             previously only defined main/sub, which combined with a wrong assumption in
--             RDM.lua was forcing an empty range slot in EnspellMelee mode. Corrected: this
--             mode wants Kaja Bow locked in exactly like DualWeapons does.
-- =============================================================================

function user_job_setup()
	-- Options: Override default values
    state.OffenseMode:options('Normal','Acc','FullAcc')
    state.HybridMode:options('Normal','DT')
	state.WeaponskillMode:options('Match','Proc') 
	state.AutoBuffMode:options('Off','Auto','AutoMelee')
	state.CastingMode:options('Normal','Resistant', 'Fodder', 'Proc')
    state.IdleMode:options('Normal','PDT','MDT')
    state.PhysicalDefenseMode:options('PDT','NukeLock')
	state.MagicalDefenseMode:options('MDT')
	state.ResistDefenseMode:options('MEVA')
	state.Weapons:options('None','DualWeapons','EnspellMelee')	
	-- =========================================================================
	-- Additional local binds — every keybind noted below for quick reference.
	-- Modifier key: ^ = Ctrl, ! = Alt, @ = Win, ~ = Shift
	-- =========================================================================
	send_command('bind ^@!` input /ja "Accession" <me>')          -- Ctrl+Win+Alt + `  : Accession on self (boosts next spell's magic burst damage)
	send_command('bind ^backspace input /ja "Saboteur" <me>')     -- Ctrl + Backspace  : Saboteur on self (boosts enfeebling potency/landing)
	send_command('bind !backspace input /ja "Spontaneity" <t>')   -- Alt + Backspace   : Spontaneity on target (instant enfeeble/ench, no recast)
	send_command('bind @backspace input /ja "Composure" <me>')    -- Win + Backspace   : Composure on self (extends enhancing spell duration)
	send_command('bind != input /ja "Penury" <me>')               -- Alt + =           : Penury on self (halves next spell's MP cost)
	send_command('bind @= input /ja "Parsimony" <me>')            -- Win + =           : Parsimony on self (halves next spell's MP cost, JP-boosted)
	send_command('bind ^delete input /ja "Dark Arts" <me>')       -- Ctrl + Delete     : Dark Arts on self (SCH subjob)
	send_command('bind !delete input /ja "Addendum: Black" <me>') -- Alt + Delete      : Addendum: Black on self (SCH subjob, pairs with Dark Arts)
	send_command('bind @delete input /ja "Manifestation" <me>')   -- Win + Delete      : Manifestation on self (SCH subjob, MP-to-damage conversion)
	-- [FIX 2026-07-25]: @f10 (cycle RecoverMode) removed -- RecoverMode is retired, MP
	-- recovery is now global/automatic via try_recover_mp(). @F10 is free again.

	-- Alt + a : Cycle weapon modes (None -> DualWeapons -> EnspellMelee -> loop). Both
	-- DualWeapons and EnspellMelee are locked in place via RDM.lua's job_customize_idle_set
	-- /job_customize_melee_set hooks, so they hold firm through movement/combat transitions.
	
	select_default_macro_book()
end

function init_gear_sets()
	--------------------------------------
	-- Start defining the sets
	--------------------------------------
	
	-- Precast Sets
	
	-- Precast sets to enhance JAs
	sets.precast.JA['Chainspell'] = {body="Vitiation Tabard +3"}
	

	-- Waltz set (chr and vit)
	sets.precast.Waltz = {}
		
	-- Don't need any special gear for Healing Waltz.
	sets.precast.Waltz['Healing Waltz'] = {}

	-- Fast cast sets for spells
	
	sets.precast.FC =  {  
		main="Emissary",
        head = "Atrophy Chapeau +3",
        body  ="Vitiation Tabard +3",
        legs  ="Ayanmo Cosciales +2",
        hands ="Leyline Gloves",
        feet  ="Bunzi's Sabots",
        ear1  ="Malignance Earring",
        ear2  ="Lethargy Earring",
        ring1="Naji's Loop",
        ring2 ="Lebeche Ring",
        waist ="Embla Sash",
        neck = "Voltsurge Torque"
    }
	
	sets.precast.FC.Enfeebling = set_combine(sets.precast.FC, {head="Lethargy Chappel +3"})
    sets.precast.Stoneskin     = set_combine(sets.precast.FC, {waist="Siegel Sash", legs="Querkening Brais"})
    sets.precast.FC.Impact     = set_combine(sets.precast.FC, {head=empty, body="Twilight Cloak", ring1 ="Archon Ring"})
    sets.precast.FC.Utsusemi   = set_combine(sets.precast.FC, {neck="Magoraga Beads"})
    sets.precast.FC.Dispelga   = set_combine(sets.precast.FC, {main="Daybreak", sub="Culminus"})

	-- [FIX 1]: Renamed sets.precast['Healing Magic'] to properly sit alongside its midcast
	--          counterpart below — no functional change here, just noted for clarity.
	sets.precast['Healing Magic'] = set_combine(sets.precast.FC, {
        main  ="Chtatoyan Staff",
        sub   ="Achaq Grip",
        legs="Doyen Pants",
        body="Vanya Robe",

    })
       
	-- Weaponskill sets
	-- Default set for any weaponskill that isn't any more specifically defined
	sets.precast.WS = {
	    head  ="Vitiation Chapeau +3",
        body  ="Malignance Tabard",
        legs  ="Malignance Tights",
        hands ="Atrophy Gloves +4",
        feet  ="Lethargy Houseaux +3",
        neck  ="Fiota Gorget",
        back  ="Sucellos's Cape",
        waist ="Fiota Belt",
        ear2  ="Ishvara Earring",
        ear1  ="Sherida Earring",
        ring1 ="Ayanmo Ring",
        ring2 ="Mujin Band",

    }
		
	sets.precast.WS.Proc = 	sets.precast.WS

	-- Midcast Sets

	sets.TreasureHunter = set_combine(sets.TreasureHunter, {ammo="Perfect Lucky Egg", waist="Chaac Belt"})
	
	-- Gear that converts elemental damage done to recover MP.	
	sets.RecoverMP = {}

	sets.midcast.FastRecast = sets.precast.FC

	-- =========================================================================
	-- [FIX 2]: Base cure set renamed from sets.midcast.Cure to sets.midcast['Healing Magic']
	--          to match the naming convention used in your WHM/BLM files. This also resolves
	--          the crash where LightDayCure referenced sets.midcast['Healing Magic'] before
	--          anything by that name existed — set_combine(nil, {...}) throws immediately
	--          and halts the whole file from loading.
	-- =========================================================================
    sets.midcast['Healing Magic'] = { 
		main  ="Chatoyant Staff",
        sub   ="Achaq Grip",
        head  ="Vanya Hood",
        body  ="Bunzi's Robe",
        hands ="Bokwus Gloves",
        neck  ="Nodens Gorget",
        ear2  ="Mendicant's Earring",
        ear1  ="Glorious Earring",
        ring2 ="Janniston Ring",
        ring1="Naji's Loop",
        back  ="Ghostfyre Cape",
        legs  ="Atrophy Tights +2",
        feet  ="Vanya Clogs",
}

	sets.precast.Cure=set_combine(sets.precast.FC['Healing Magic'],{legs="Doyen Pants", body="Vanya Robe"})


    sets.midcast.LightWeatherCure = {}

	-- [FIX 2 cont.]: This now resolves correctly since Healing Magic is defined above it.
    sets.midcast.LightDayCure     = set_combine(sets.midcast['Healing Magic'], {waist=gear.default.obi_weather})

	-- [FIX 3]: Removed the duplicate/dead early definitions of Cursna and StatusRemoval
	--          that were immediately overwritten by the fuller versions a few lines later
	--          in the original file (dead code, last-definition-wins). Kept only the
	--          versions that actually take effect, for clarity.
	sets.midcast.StatusRemoval    = set_combine(sets.midcast.FastRecast, {main=gear.grioavolr_fc_staff, sub="Clemency Grip"})

	sets.midcast.Cursna = set_combine(sets.midcast.Cure, {
		neck="Debilis Medallion", hands="Hieros Mittens",
		back="Oretan. Cape +1", ring1="Haoma's Ring", ring2="Menelaus's Ring",
		waist="Witful Belt", feet="Vanya Clogs"
	})
		
	sets.midcast.Curaga = sets.midcast.Cure
	sets.Self_Healing = {}
	sets.Cure_Received = {}
	sets.Self_Refresh = {}

	sets.midcast['Enhancing Magic'] = {
	    head  ="Umuthi Hat",
        body  ="Vitiation Tabard +3",
        legs  ="Atrophy Tights +2",
        hands ="Atrophy Gloves +4",
        feet  ="Lethargy Houseaux +3",
        neck  ="Duelist's Torque +1",
        ear1  ="Andoaa Earring",
        ear2  ="Lethargy Earring",
        ring1 ="Murky Ring",
        ring2 ="Lebeche Ring",
        back  ="Estoqueur's Cape",
        waist ="Embla Sash"
    }

	--Atrophy Gloves are better than Lethargy for me despite the set bonus for duration on others.		
	sets.buff.ComposureOther = {head="Leth. Chappel +2",
		body="Lethargy Sayon +3",hands="Leth. Gantherots +2",
		legs="Leth. Fuseau +2",feet="Leth. Houseaux +3"}
		
	--Red Mage enhancing sets are handled in a different way from most, layered on due to the way Composure works
	--Don't set combine a full set with these spells, they should layer on Enhancing Set > Composure (If Applicable) > Spell

	sets.midcast.BoostStat = {hands="Viti. Gloves +2"}
	sets.Self_Refresh  = set_combine(sets.midcast['Enhancing Magic'],{feet="Inspirited Boots"})
    sets.midcast.Regen       = set_combine(sets.midcast['Enhancing Magic'], {main="Bolelabunga"})
    sets.EnhancingSkill      = set_combine(sets.midcast['Enhancing Magic'], {hands="Vitiation Gloves +3"})
    sets.midcast.Refresh     = set_combine(sets.midcast['Enhancing Magic'], {legs="Lethargy Fuseau +3", body="Atrophy Tabard +4"})
    sets.precast.Aquaveil    = set_combine(sets.precast.FC, {hands="Vitiation Gloves +3"})
    sets.midcast.BarElement  = set_combine(sets.midcast['Enhancing Magic'], {hands="Vitiation Gloves +3"})
    sets.midcast.Temper      = set_combine(sets.midcast['Enhancing Magic'], {})
    sets.midcast.Temper.DW   = set_combine(sets.midcast.Temper, {})
    sets.midcast.Enspell     = set_combine(sets.midcast.Temper, {back="Ghostfyre Cape", legs="Vitiation Tights +4", head="Umuthi Hat", main="Archduke's Sword"})
    sets.midcast.Enspell.DW  = set_combine(sets.midcast.Enspell, {})
    sets.midcast.Stoneskin   = set_combine(sets.midcast['Enhancing Magic'], {waist="Siegel Sash", legs="Shedir Seraweels", head="Umuthi Hat", hands="Vitiation Gloves +3", neck  ="Nodens Gorget",})
    sets.midcast.ShockSpikes = set_combine(sets.midcast['Enhancing Magic'], {legs="Vitiation Tights +4"})
    sets.midcast.BlazeSpikes = set_combine(sets.midcast.ShockSpikes, {})
    sets.midcast.IceSpikes   = set_combine(sets.midcast.ShockSpikes, {})
    sets.midcast.Gain        = set_combine(sets.midcast['Enhancing Magic'], {hands="Vitiation Gloves +3"})
    sets.precast.JA.Chainspell = {body="Vitiation Tabard +3"}

	
	sets.midcast['Enfeebling Magic'] =  
    {
		main  ="Mpaca's Staff",
        sub="Mephitis Grip",
        head  ="Vitiation Chapeau +3",
        body  ="Lethargy Sayon +3",
        legs  ="Lethargy Fuseau +3",
        hands ="Lethargy Gantherots +3",
        feet  ="Vitiation Boots +3",
        neck  ="Duelist's Torque +1",
        ring2 ="Jhakri Ring",
        ring1="Crepuscular Ring",
        back  ="Sucellos's Cape",
        waist ="Null Belt",
        ear2  ="Lethargy Earring",
        ear1  ="Malignance Earring",
        range="Kaja Bow"
    }
		
	sets.midcast['Enfeebling Magic'].Resistant = set_combine(sets.midcast['Enfeebling Magic'], {
        back ="Null Shawl",
        main ="Chatoyant Staff",
        ear1="Snotra Earring",
        sub="Flanged Grip",
        ring1="Vertigo Ring",
        neck="Null Loop",
        range="Kaja Bow"
    })		
	sets.midcast.DurationOnlyEnfeebling = set_combine(sets.midcast['Enfeebling Magic'], {body="Atrophy Tabard +4",range="Kaja Bow", ear1="Snotra Earring", waist=" Obstinate Sash"})
	sets.midcast.Silence = sets.midcast.DurationOnlyEnfeebling
	sets.midcast.Silence.Resistant = sets.midcast['Enfeebling Magic'].Resistant
	sets.midcast.Sleep = set_combine(sets.midcast.DurationOnlyEnfeebling,{})
	sets.midcast.Sleep.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Bind = set_combine(sets.midcast.DurationOnlyEnfeebling,{})
	sets.midcast.Bind.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Break = set_combine(sets.midcast.DurationOnlyEnfeebling,{})
	sets.midcast.Break.Resistant = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{waist="Acuity Belt +1"})
	sets.midcast.Dispel = sets.midcast['Enfeebling Magic'].Resistant
	sets.midcast.Dispelga = set_combine(sets.midcast['Enfeebling Magic'].Resistant,{main="Daybreak", sub="Culminus"})



	sets.midcast.SkillBasedEnfeebling = set_combine(sets.midcast['Enfeebling Magic'], {ear1="Vor Earring",hands="Leth. Gantherots +1",ring1="Stikini Ring +1",legs="Psycloth Lappas"})
	
    sets.midcast['Frazzle II']            = sets.midcast['Enfeebling Magic'].Resistant
    sets.midcast['Frazzle III']           = sets.midcast.SkillBasedEnfeebling
    sets.midcast['Frazzle III'].Resistant = sets.midcast['Enfeebling Magic'].Resistant
    sets.midcast['Distract III']          = sets.midcast.SkillBasedEnfeebling
    sets.midcast['Distract III'].Resistant = sets.midcast['Enfeebling Magic'].Resistant

	-- =========================================================================
	-- [FIX 4]: sets.midcast['Elemental Magic'] moved UP here, above Divine Magic,
	--          MagicBurst, and Dark Magic — all three of which reference it via
	--          set_combine. In the original file it was defined ~40 lines further
	--          down, so those three set_combine calls were passing nil as their
	--          base table, which throws and halts the entire file from loading.
	-- =========================================================================
    sets.midcast['Elemental Magic'] = {
        main  ="Marin Staff +1",
        sub   ="Willpower Grip",
        ammo  ="Ghastly Tathlum",
        head  ="Lethargy Chappel +3",
        body  ="Bunzi's Robe",
        legs  ="Lethargy Fuseau +3",
        hands ="Lethary Gantherots +2",
        feet  ="Vitiation Boots +3",
        neck  ="Baetyl Pendant",
        ear1  ="Malignance Earring",
        ear2  ="Hecate's Earring",
        ring2 ="Jhakri Ring",
        ring1 ="Resonance Ring",
        back  ="Izdubar Mantle",
        waist ="Hachirin-no-obi"
    }
		
	sets.midcast['Elemental Magic'].Resistant = set_combine(sets.midcast['Elemental Magic'], {
		main = "Mpaca's Staff",
		neck = "Incanter's Torque",
		head = "Atrophy Chapeau +3",
		waist = "Null Belt",
		back = "Null Shawl",
        range="Kaja Bow"
	})
		
    sets.midcast['Elemental Magic'].Fodder = set_combine(sets.midcast['Elemental Magic'], {})
    sets.midcast['Elemental Magic'].Proc   = set_combine(sets.midcast['Elemental Magic'], {
    })

    sets.midcast['Elemental Magic'].HighTierNuke           = set_combine(sets.midcast['Elemental Magic'], {})
    sets.midcast['Elemental Magic'].HighTierNuke.Resistant = set_combine(sets.midcast['Elemental Magic'].Resistant, {})
    sets.midcast['Elemental Magic'].HighTierNuke.Fodder    = set_combine(sets.midcast['Elemental Magic'].Fodder, {})

    sets.midcast.Impact = set_combine(sets.midcast['Elemental Magic'], {head=empty, body="Twilight Cloak"})

	-- Gear for Magic Burst mode. (combines against the now fully-defined Elemental Magic set)
    sets.MagicBurst = set_combine(sets.midcast['Elemental Magic'], {
        main="Bunzi's Rod", 
        sub="Culminus",
        head = "Atrophy Chapeau +3",
        body="Bunzi's Robe",
        hands="Bunzi's Gloves",
        legs="Lethargy Fuseau +3",
        feet="Bunzi's Sabots",
        neck  ="Mizukage-no-Kubikazari",
        ring2 ="Mujin Band",
        ring1 ="Locus Ring",

    })
    sets.ResistantMagicBurst = set_combine(sets.MagicBurst, {})

	-- [FIX 4 cont.]: Divine Magic now resolves correctly, since Elemental Magic exists above it.
	sets.midcast['Divine Magic'] = set_combine(sets.midcast['Elemental Magic'], {
        feet="Medium's Sabots",
        body="Vanya Robe",
    })

	sets.midcast.Dia = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast.Diaga = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Dia II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Dia III'] = set_combine(sets.midcast['Enfeebling Magic'], {waist="Chaac Belt"})
	
	sets.midcast.Bio = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Bio II'] = set_combine(sets.midcast['Enfeebling Magic'], sets.TreasureHunter)
	sets.midcast['Bio III'] = set_combine(sets.midcast['Enfeebling Magic'], {head="Viti. Chapeau +3",waist="Chaac Belt",feet=gear.chironic_treasure_feet})

	 sets.midcast['Dark Magic'] = {
        head  ="Jhakri Coronal +2",
        body  ="Jhakri Robe +2",
        legs  ="Jhakri Slops +2",
        hands ="Malignance Gloves",
        feet  ="Jhakri Pigaches +2",
        neck  ="Erra Pendant",
        ear2  ="Abyssal Earring",
        ear1  ="Malignance Earring",
        ring1 ="Crepuscular Ring",
        ring2="Evanescence Ring",
        back  ="Izdubar Mantle",
        waist ="Eschan Stone",
        ammo="Ghastly Tathlum"
    }

    sets.midcast.Drain          = set_combine(sets.midcast['Dark Magic'], {neck="Erra Pendant"})
    sets.midcast.Aspir          = set_combine(sets.midcast.Drain, {waist="Fucho-no-obi", feet="Merlinic Crackows"})
    sets.midcast.Stun           = set_combine(sets.midcast['Dark Magic'], {})
    sets.midcast.Stun.Resistant = set_combine(sets.midcast['Dark Magic'], {})


	-- Sets for special buff conditions on spells.
		
  sets.buff.Saboteur      = {hands="Lethargy Gantherots +3"}
    sets.buff.Sublimation   = {waist="Embla Sash"}
    sets.buff.DTSublimation = {waist="Embla Sash"}
    sets.HPDown             = {}
    sets.HPCure             = {}
    sets.buff.Doom          = {}
	-- Sets to return to when not performing an action.
	
	-- Resting sets
	sets.resting = {main="Chatoyant Staff",sub="Oneiros Grip",}
	

	-- Idle sets
	sets.idle = { 
        main="Mpaca's Staff",
        sub="Umbra Strap",
        ammo  ="Crepuscular Pebble",
        head  ="Vitiation Chapeau +3",
        body  ="Lethargy Sayon +3",
        legs  ="Carmine Cuisses +1",
        hands ="Malignance Gloves",
        feet  ="Battlecast Gaiters",
        neck  ="Null Loop",
        ear1  ="Moonshade Earring",
        ear2  ="Alabaster Earring",
        ring1="Ayanmo Ring",
        ring2 ="Murky Ring",
        back  ="Archon Cape",
        waist ="Null Belt"}
		
	sets.idle.PDT     = set_combine(sets.idle, 
	{main="Chatoyant Staff",
        sub="Umbra Strap",})
    sets.idle.MDT     = set_combine(sets.idle, {})
    sets.idle.Weak    = set_combine(sets.idle, {})
    sets.idle.DTHippo = set_combine(sets.idle, {})
	
	sets.idle.DTHippo = set_combine(sets.idle.PDT, {
	back="Umbra Cape",
	legs="Carmine Cuisses +1",
	--feet="Hippo. Socks +1"
	})
	
	-- Defense sets
	sets.defense.PDT = {}

	sets.defense.NukeLock = sets.midcast['Elemental Magic']
		
	sets.defense.MDT =  set_combine(sets.idle.MDT,{})
		
    sets.defense.MEVA = set_combine(sets.defense.MDT,{})
		
	sets.Kiting = {legs="Carmine Cuisses +1"}
	sets.latent_refresh = {waist="Fucho-no-obi"}
	sets.latent_refresh_grip = {main= "Mpaca's Staff", sub="Oneiros Grip"}
	sets.TPEat = {neck="Chrys. Torque"}
	sets.DayIdle = {}
	sets.NightIdle = {}
	
	-- Weapons sets
	sets.weapons.Naegling = {main="Naegling",sub="Archduke's Shield"} -- Default (non-NIN sub) Naegling loadout
	sets.weapons.DualWeapons = {main="Naegling", sub="Demersal Degen +1", range="Kaja Bow", ammo=empty } -- Ctrl+W cycle target for NIN-sub dual wield; ammo/range locked via RDM.lua's job_customize_idle_set/melee_set
	sets.weapons.EnspellMelee = {main="Naegling", sub="Culminus", range="Kaja Bow",ammo=empty} -- Non-NIN-sub melee: rides enspell procs via Culminus instead of using a shield; Kaja Bow locked same as DualWeapons
	sets.weapons.DualBow = {main="Naegling",sub="Demersal Degen +1",range="Kaja Bow"}
	sets.weapons.BowMacc = {range="Kaja Bow",ammo=empty}

	-- Elemental bonus overlay sets. sets.element[spell.element] is applied on top of nukes in
	-- RDM.lua's job_post_midcast, and sets.element.enspell[element] is applied on top of melee
	-- gear in job_customize_melee_set when an enspell is active. Neither table existed before --
	-- both call sites were indexing a nil sets.element and crashing (nukes AND enspelled melee).
	-- Stubbed blank per element below so nothing crashes; drop real gear into whichever elements
	-- you actually use.
	sets.element = {
		Fire = {},
		Ice = {},
		Wind = {},
		Earth = {},
		Lightning = {},
		Water = {},
		Light = {},
		Dark = {},
	}
	sets.element.enspell = {
		Fire = {},
		Ice = {},
		Wind = {},
		Earth = {},
		Lightning = {},
		Water = {},
		Light = {},
		Dark = {},
	}
    sets.buff.Sublimation = {waist="Embla Sash"}
    sets.buff.DTSublimation = {waist="Embla Sash"}

	-- Engaged sets

	-- Variations for TP weapon and (optional) offense/defense modes.  Code will fall back on previous
	-- sets if more refined versions aren't defined.
	-- If you create a set with both offense and defense modes, the offense mode should be first.
	-- EG: sets.Dagger.Accuracy.Evasion
	
	-- Normal melee group
--	sets.engaged = {ammo="Aurgelmir Orb +1",
--		head="Aya. Zucchetto +2",neck="Asperity Necklace",ear1="Cessance Earring",ear2="Cessance Earring",
--		body="Ayanmo Corazza +2",hands="Aya. Manopolas +2",ring1="Petrov Ring",ring2="Ilabrat Ring",
--		back=gear.stp_jse_back,waist="Windbuffet Belt +1",legs="Carmine Cuisses +1",feet="Carmine Greaves +1"}

sets.engaged = {  
        neck  ="Lissome Necklace",
        ear1  ="Sherida Earring",
        ear2  ="Cessance Earring",
        body  ="Malignance Tabard",
        hands ="Malignance Gloves",
        ring1 ="Mars's Ring",
        ring2 ="Rajas Ring",
        back="Sucellos's Cape",
        waist ="Sailfi Belt +1",
        legs  ="Malignance Tights",
        feet  ="Ayanmo Gambieras +2",
        ammo  ="Ginsen"}

sets.engaged.EnspellMelee = sets.engaged

sets.engaged.Acc = set_combine(sets.engaged, {range="Kaja Bow", waist="Null Loop"})
sets.engaged.FullAcc = set_combine(sets.engaged.Acc, {back="Null Cape", neck="Null Loop",})
sets.engaged.DT = set_combine(sets.engaged, {})

sets.engaged.Acc.DT = set_combine(sets.engaged.Acc, {})
sets.engaged.FullAcc.DT = set_combine(sets.engaged.FullAcc, {})

sets.engaged.DW = set_combine(sets.engaged, {})
sets.engaged.DW.Acc = set_combine(sets.engaged.Acc, {})
sets.engaged.DW.FullAcc = set_combine(sets.engaged.FullAcc, {})
sets.engaged.DW.DT = set_combine(sets.engaged, {})

sets.engaged.DW.Acc.DT = set_combine(sets.engaged.Acc, {})
sets.engaged.DW.FullAcc.DT = set_combine(sets.engaged.FullAcc, {})
end



-- [FIX5] Removed job_handle_equipping_gear AND job_self_command from this file entirely.
-- job_self_command already exists in RDM.lua (handles 'gs c elemental' / 'gs c smartcure')
-- — defining it again here silently overwrote it, since this gear file loads after the
-- job file (last-definition-wins). The bow/ammo lock for DualWeapons mode now lives in
-- RDM.lua's job_customize_idle_set / job_customize_melee_set instead, which are the
-- correct, already-established hook points for this and don't collide with anything.

function select_default_macro_book()
    set_macro_page(1, 3)
end

function user_job_lockstyle()
    send_command('input /lockstyleset 3')
end